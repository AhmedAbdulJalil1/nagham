import { useEffect, useRef, useState } from "react";
import { FolderOpen } from "lucide-react";
import { PlayerProvider, usePlayer } from "./player/PlayerContext";
import Sidebar, { type TabId } from "./components/Sidebar";
import LibraryView from "./components/LibraryView";
import PlayerBar from "./components/PlayerBar";
import NowPlaying from "./components/NowPlaying";
import VideoPlayer from "./components/VideoPlayer";
import {
  EqualizerModal,
  PlaylistModal,
  SleepTimerModal,
} from "./components/Modals";

function AppShell() {
  const p = usePlayer();
  const fileRef = useRef<HTMLInputElement | null>(null);
  const [tab, setTab] = useState<TabId>("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const [nowPlaying, setNowPlaying] = useState(false);
  const [eqOpen, setEqOpen] = useState(false);
  const [sleepOpen, setSleepOpen] = useState(false);
  const [playlistFor, setPlaylistFor] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  const openFiles = () => fileRef.current?.click();
  const isVideo = p.current?.type === "video";

  /* ===== سحب وإفلات الملفات ===== */
  useEffect(() => {
    const onDrag = (e: DragEvent) => {
      e.preventDefault();
      if (e.type === "dragover" || e.type === "dragenter") setDragging(true);
      else setDragging(false);
    };
    const onDrop = (e: DragEvent) => {
      e.preventDefault();
      setDragging(false);
      if (e.dataTransfer?.files?.length) p.addFiles(Array.from(e.dataTransfer.files));
    };
    window.addEventListener("dragover", onDrag);
    window.addEventListener("dragenter", onDrag);
    window.addEventListener("dragleave", onDrag);
    window.addEventListener("drop", onDrop);
    return () => {
      window.removeEventListener("dragover", onDrag);
      window.removeEventListener("dragenter", onDrag);
      window.removeEventListener("dragleave", onDrag);
      window.removeEventListener("drop", onDrop);
    };
  }, [p]);

  /* ===== اختصار مسافة ===== */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      if (e.code === "Space") {
        e.preventDefault();
        p.playPause();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [p]);

  /* ===== عنوان الصفحة ===== */
  useEffect(() => {
    document.title = p.current ? `${p.current.name} — نغم` : "نغم — مشغّل الموسيقى والفيديو";
  }, [p.current?.id]);

  /* ===== قفل التمرير عند النوافذ ===== */
  useEffect(() => {
    const locked = nowPlaying || isVideo || eqOpen || sleepOpen || playlistFor !== null;
    document.body.style.overflow = locked ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [nowPlaying, isVideo, eqOpen, sleepOpen, playlistFor]);

  return (
    <div className="min-h-screen bg-[#08080f] text-white flex flex-col">
      {/* خلفية زخرفية */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute top-[-120px] right-[-100px] h-96 w-96 rounded-full bg-violet-600/15 blur-3xl" />
        <div className="absolute bottom-[-100px] left-[-100px] h-96 w-96 rounded-full bg-fuchsia-600/10 blur-3xl" />
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 h-72 w-72 rounded-full bg-amber-500/[0.06] blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-1 min-h-screen">
        <Sidebar
          tab={tab}
          onTab={setTab}
          tracks={p.tracks}
          favsCount={p.favs.length}
          playlistsCount={p.playlists.length}
          openFiles={openFiles}
        />
        <main className="flex-1 min-w-0">
          <LibraryView
            tab={tab}
            onTab={setTab}
            search={search}
            onSearch={setSearch}
            sort={sort}
            onSort={setSort}
            openFiles={openFiles}
            onManagePlaylists={() => setPlaylistFor(null)}
            onAddToPlaylist={(id) => setPlaylistFor(id)}
          />
        </main>
      </div>

      {/* شريط التشغيل */}
      <PlayerBar
        onOpenNowPlaying={() => setNowPlaying(true)}
        onOpenEq={() => setEqOpen(true)}
        onOpenSleep={() => setSleepOpen(true)}
      />

      {/* النوافذ */}
      {nowPlaying && !isVideo && (
        <NowPlaying
          onClose={() => setNowPlaying(false)}
          onOpenEq={() => setEqOpen(true)}
          onOpenSleep={() => setSleepOpen(true)}
          onAddToPlaylist={(id) => setPlaylistFor(id)}
        />
      )}
      {isVideo && <VideoPlayer />}
      {eqOpen && <EqualizerModal onClose={() => setEqOpen(false)} />}
      {sleepOpen && <SleepTimerModal onClose={() => setSleepOpen(false)} />}
      {playlistFor !== null && (
        <PlaylistModal onClose={() => setPlaylistFor(null)} trackId={playlistFor} />
      )}

      {/* التنبيهات */}
      <div className="fixed top-4 inset-x-0 z-[80] flex flex-col items-center gap-2 pointer-events-none px-4">
        {p.toasts.map((t) => (
          <div
            key={t.id}
            className="anim-toast rounded-2xl glass bg-[#16161f]/95 border-white/10 px-5 py-3 text-sm font-bold shadow-2xl shadow-black/50"
          >
            {t.msg}
          </div>
        ))}
      </div>

      {/* مدخل الملفات المخفي */}
      <input
        ref={fileRef}
        type="file"
        multiple
        accept="audio/*,video/*,.mp3,.m4a,.aac,.ogg,.wav,.flac,.opus,.mp4,.webm,.mkv,.mov"
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) p.addFiles(Array.from(e.target.files));
          e.target.value = "";
        }}
      />

      {/* طبقة السحب */}
      {dragging && (
        <div className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-sm grid place-items-center pointer-events-none">
          <div className="rounded-3xl border-2 border-dashed border-fuchsia-400/60 bg-fuchsia-500/10 px-12 py-10 text-center anim-scale-in">
            <FolderOpen className="h-12 w-12 text-fuchsia-300 mx-auto mb-3" />
            <p className="text-lg font-black">أفلت الملفات هنا</p>
            <p className="text-sm text-white/50 mt-1">سيتم إضافتها لمكتبتك فورًا</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <PlayerProvider>
      <AppShell />
    </PlayerProvider>
  );
}
