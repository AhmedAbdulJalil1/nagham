import { useEffect, useMemo, useState } from "react";
import {
  Check,
  ChevronRight,
  Film,
  FolderOpen,
  Heart,
  History,
  ListMusic,
  ListPlus,
  Music2,
  Music4,
  Play,
  Plus,
  Search,
  Trash2,
  Waves,
  X,
  type Home,
} from "lucide-react";
import { usePlayer } from "../player/PlayerContext";
import { artGradient, formatBytes, formatTime } from "../lib/utils";
import type { Playlist, Track } from "../types";
import type { TabId } from "./Sidebar";

interface Props {
  tab: TabId;
  onTab: (t: TabId) => void;
  search: string;
  onSearch: (s: string) => void;
  sort: string;
  onSort: (s: string) => void;
  openFiles: () => void;
  onManagePlaylists: () => void;
  onAddToPlaylist: (trackId: string) => void;
}

const TABS: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: "all", label: "الكل", icon: Music4 },
  { id: "music", label: "الموسيقى", icon: Music2 },
  { id: "video", label: "الفيديو", icon: Film },
  { id: "favs", label: "المفضلة", icon: Heart },
  { id: "playlists", label: "القوائم", icon: ListMusic },
  { id: "history", label: "السجل", icon: History },
];

const SORTS = [
  { id: "newest", label: "الأحدث إضافة" },
  { id: "oldest", label: "الأقدم" },
  { id: "name", label: "الاسم (أ - ي)" },
  { id: "size", label: "الأكبر حجمًا" },
];

function Art({ track, className }: { track: Track; className: string }) {
  if (track.type === "audio") {
    return (
      <div
        className={`${className} grid place-items-center shrink-0 shadow-lg`}
        style={{ background: artGradient(track.name) }}
      >
        <Music2 className="h-1/2 w-1/2 text-white/80" />
      </div>
    );
  }
  if (track.thumbnail) {
    return (
      <img src={track.thumbnail} alt="" className={`${className} shrink-0 object-cover shadow-lg`} />
    );
  }
  return (
    <div
      className={`${className} grid place-items-center shrink-0 shadow-lg bg-gradient-to-br from-violet-600 to-fuchsia-600`}
    >
      <Film className="h-1/2 w-1/2 text-white/80" />
    </div>
  );
}

function TrackCard({
  track,
  onPlay,
  onFav,
  onAdd,
  onDelete,
  isFav,
  isCurrent,
  isPlaying,
}: {
  track: Track;
  onPlay: () => void;
  onFav: () => void;
  onAdd: () => void;
  onDelete: () => void;
  isFav: boolean;
  isCurrent: boolean;
  isPlaying: boolean;
}) {
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!confirming) return;
    const t = window.setTimeout(() => setConfirming(false), 2600);
    return () => window.clearTimeout(t);
  }, [confirming]);

  return (
    <div
      className={`group relative flex items-center gap-3 rounded-2xl p-2.5 pr-3 border transition ${
        isCurrent
          ? "border-fuchsia-400/30 bg-fuchsia-500/10"
          : "border-white/5 bg-white/[0.03] hover:bg-white/[0.07]"
      }`}
    >
      <button onClick={onPlay} className="relative shrink-0">
        <Art track={track} className="h-14 w-14 rounded-xl" />
        <span className="absolute inset-0 grid place-items-center rounded-xl bg-black/40 opacity-0 group-hover:opacity-100 transition">
          <Play className="h-5 w-5 fill-white text-white" />
        </span>
        {isPlaying && isCurrent && (
          <span className="absolute -top-1.5 -right-1.5 grid place-items-center h-5 w-5 rounded-full bg-fuchsia-500">
            <Waves className="h-3 w-3 text-white" />
          </span>
        )}
      </button>

      <div className="flex-1 min-w-0 text-right">
        <p className={`truncate text-[13px] font-bold ${isCurrent ? "text-fuchsia-200" : ""}`}>
          {track.name}
        </p>
        <p className="mt-0.5 text-[10px] text-white/40 flex items-center gap-1.5">
          <span>{track.type === "audio" ? "🎵 موسيقى" : "🎬 فيديو"}</span>
          <span>•</span>
          <span>{formatBytes(track.size)}</span>
          {track.duration ? (
            <>
              <span>•</span>
              <span dir="ltr">{formatTime(track.duration)}</span>
            </>
          ) : null}
        </p>
      </div>

      <div className="relative z-20 flex items-center gap-0.5 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition">
        <button onClick={onFav} className={`grid place-items-center h-8 w-8 rounded-lg transition ${isFav ? "text-rose-400" : "text-white/40 hover:text-rose-400"}`}>
          <Heart className={`h-4 w-4 ${isFav ? "fill-rose-400" : ""}`} />
        </button>
        <button onClick={onAdd} className="grid place-items-center h-8 w-8 rounded-lg text-white/40 hover:text-fuchsia-300">
          <ListPlus className="h-4 w-4" />
        </button>
        <button
          onClick={() => {
            if (confirming) {
              onDelete();
              setConfirming(false);
            } else setConfirming(true);
          }}
          className={`grid place-items-center h-8 w-8 rounded-lg transition ${
            confirming ? "bg-rose-500/20 text-rose-300" : "text-white/40 hover:text-rose-400"
          }`}
          title={confirming ? "اضغط للتأكيد" : "حذف"}
        >
          {confirming ? <Check className="h-4 w-4" /> : <Trash2 className="h-4 w-4" />}
        </button>
      </div>

      <button
        onClick={onPlay}
        className="absolute inset-0 z-10 sm:hidden"
        aria-label="تشغيل"
      />
    </div>
  );
}

function EmptyState({
  icon: Icon,
  title,
  desc,
  action,
  onAction,
}: {
  icon: typeof Music2;
  title: string;
  desc: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center anim-fade-up">
      <div className="h-20 w-20 rounded-3xl glass grid place-items-center mb-5">
        <Icon className="h-9 w-9 text-fuchsia-300" />
      </div>
      <h3 className="text-lg font-black">{title}</h3>
      <p className="mt-1.5 text-sm text-white/40 max-w-xs">{desc}</p>
      {action && onAction && (
        <button
          onClick={onAction}
          className="mt-6 flex items-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-fuchsia-600 px-6 py-3 text-sm font-bold shadow-lg shadow-fuchsia-600/30 active:scale-95 transition"
        >
          <FolderOpen className="h-4 w-4" />
          {action}
        </button>
      )}
    </div>
  );
}

export default function LibraryView({
  tab,
  onTab,
  search,
  onSearch,
  sort,
  onSort,
  openFiles,
  onManagePlaylists,
  onAddToPlaylist,
}: Props) {
  const p = usePlayer();
  const [playlistOpen, setPlaylistOpen] = useState<Playlist | null>(null);

  const visible = useMemo(() => {
    let list: Track[] = [];
    if (tab === "music") list = p.tracks.filter((t) => t.type === "audio");
    else if (tab === "video") list = p.tracks.filter((t) => t.type === "video");
    else if (tab === "favs") list = p.tracks.filter((t) => p.favs.includes(t.id));
    else if (tab === "history") {
      const byId = new Map(p.tracks.map((t) => [t.id, t]));
      list = p.history.map((id) => byId.get(id)).filter((t): t is Track => Boolean(t));
    } else list = [...p.tracks];

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((t) => t.name.toLowerCase().includes(q));
    }

    if (tab !== "history") {
      if (sort === "oldest") list.sort((a, b) => a.addedAt - b.addedAt);
      else if (sort === "name") list.sort((a, b) => a.name.localeCompare(b.name, "ar"));
      else if (sort === "size") list.sort((a, b) => b.size - a.size);
      else list.sort((a, b) => b.addedAt - a.addedAt);
    }
    return list;
  }, [tab, p.tracks, p.favs, p.history, search, sort]);

  const playList = (ids: string[], startId: string) => p.playFrom(ids, startId);

  const totalTime = visible.reduce((s, t) => s + (t.duration || 0), 0);

  const headerTitle =
    tab === "music" ? "الموسيقى" : tab === "video" ? "الفيديو" : tab === "favs" ? "المفضلة" : tab === "playlists" ? "قوائم التشغيل" : tab === "history" ? "سجل الاستماع" : "المكتبة";

  return (
    <div className="mx-auto max-w-6xl px-4 md:px-6 py-5 pb-40">
      {/* الرأس */}
      <div className="flex items-center gap-3 mb-5">
        <div className="md:hidden h-10 w-10 rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-amber-400 grid place-items-center shadow-lg shadow-fuchsia-500/30">
          <Waves className="h-5 w-5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-xl md:text-2xl font-black">{headerTitle}</h2>
          <p className="text-[11px] text-white/40 font-semibold mt-0.5">
            {visible.length} ملف • {formatTime(totalTime)}
          </p>
        </div>
        <button
          onClick={openFiles}
          className="flex items-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-fuchsia-600 px-4 py-2.5 text-[13px] font-bold shadow-lg shadow-fuchsia-600/25 active:scale-95 transition"
        >
          <FolderOpen className="h-4 w-4" />
          <span className="hidden sm:inline">فتح الملفات</span>
        </button>
      </div>

      {/* البحث والفرز */}
      <div className="flex flex-col sm:flex-row gap-2.5 mb-4">
        <div className="relative flex-1">
          <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
          <input
            value={search}
            onChange={(e) => onSearch(e.target.value)}
            placeholder="ابحث في مكتبتك..."
            className="w-full rounded-2xl bg-white/[0.04] border border-white/10 py-3 pr-10 pl-4 text-sm outline-none focus:border-fuchsia-400/50 transition placeholder:text-white/25"
          />
        </div>
        <select
          value={sort}
          onChange={(e) => onSort(e.target.value)}
          className="rounded-2xl bg-white/[0.04] border border-white/10 px-4 py-3 text-sm font-bold outline-none focus:border-fuchsia-400/50 text-white/70 [&>option]:bg-[#12121c]"
        >
          {SORTS.map((s) => (
            <option key={s.id} value={s.id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>

      {/* التبويبات */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-6">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onTab(id)}
            className={`shrink-0 flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition ${
              tab === id
                ? "bg-gradient-to-l from-violet-600 to-fuchsia-600 shadow-lg shadow-fuchsia-600/25"
                : "bg-white/[0.04] text-white/55 hover:bg-white/[0.09] hover:text-white"
            }`}
          >
            <Icon className="h-3.5 w-3.5" />
            {label}
          </button>
        ))}
      </div>

      {/* المحتوى */}
      {tab === "playlists" ? (
        playlistOpen ? (
          /* تفاصيل القائمة */
          <div className="anim-fade-up">
            <button
              onClick={() => setPlaylistOpen(null)}
              className="flex items-center gap-1 text-sm font-bold text-white/50 hover:text-white mb-4"
            >
              <ChevronRight className="h-4 w-4" />
              العودة للقوائم
            </button>
            <div className="glass rounded-2xl p-5 mb-5 flex flex-wrap items-center gap-4">
              <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 grid place-items-center">
                <ListMusic className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-black truncate">{playlistOpen.name}</h3>
                <p className="text-[11px] text-white/40">
                  {playlistOpen.trackIds.length} مقطع
                </p>
              </div>
              <button
                onClick={() => {
                  const ids = playlistOpen.trackIds.filter((id) => p.tracks.some((t) => t.id === id));
                  if (ids.length) playList(ids, ids[0]);
                }}
                disabled={!playlistOpen.trackIds.length}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-l from-violet-600 to-fuchsia-600 px-4 py-2.5 text-xs font-bold disabled:opacity-40"
              >
                <Play className="h-4 w-4 fill-white" />
                تشغيل الكل
              </button>
              <button
                onClick={() => {
                  p.deletePlaylist(playlistOpen.id);
                  setPlaylistOpen(null);
                }}
                className="grid place-items-center h-10 w-10 rounded-xl bg-white/5 text-white/40 hover:text-rose-400 hover:bg-rose-500/10"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
            <div className="space-y-2">
              {playlistOpen.trackIds.map((id) => {
                const t = p.tracks.find((x) => x.id === id);
                if (!t) return null;
                const plIds = playlistOpen.trackIds.filter((x) => p.tracks.some((tr) => tr.id === x));
                return (
                  <div key={id} className="flex items-center gap-3 rounded-2xl bg-white/[0.03] border border-white/5 p-2.5 pr-3">
                    <button onClick={() => playList(plIds, id)}>
                      <Art track={t} className="h-12 w-12 rounded-xl" />
                    </button>
                    <div className="flex-1 min-w-0 text-right">
                      <p className="truncate text-[13px] font-bold">{t.name}</p>
                      <p className="text-[10px] text-white/40" dir="ltr">
                        {formatTime(t.duration || 0)}
                      </p>
                    </div>
                    <button
                      onClick={() => p.removeFromPlaylist(playlistOpen.id, id)}
                      className="grid place-items-center h-8 w-8 rounded-lg text-white/40 hover:text-rose-400"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ) : p.playlists.length === 0 ? (
          <EmptyState
            icon={ListMusic}
            title="لا توجد قوائم تشغيل"
            desc="أنشئ قوائمك الخاصة وجمّع أغانيك المفضلة في مكان واحد"
            action="إدارة القوائم"
            onAction={onManagePlaylists}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 anim-fade-up">
            {p.playlists.map((pl) => {
              const count = pl.trackIds.length;
              return (
                <button
                  key={pl.id}
                  onClick={() => setPlaylistOpen(pl)}
                  className="glass rounded-2xl p-5 text-right hover:bg-white/[0.07] transition group"
                >
                  <div className="flex items-center gap-3 mb-4">
                    <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-violet-500/40 to-fuchsia-500/40 grid place-items-center">
                      <ListMusic className="h-5 w-5 text-fuchsia-300" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-black truncate">{pl.name}</p>
                      <p className="text-[11px] text-white/40">{count} مقطع</p>
                    </div>
                  </div>
                  <div className="flex -space-x-2 space-x-reverse">
                    {pl.trackIds.slice(0, 4).map((id) => {
                      const t = p.tracks.find((x) => x.id === id);
                      return t ? (
                        <Art key={id} track={t} className="h-9 w-9 rounded-lg ring-2 ring-[#12121c]" />
                      ) : null;
                    })}
                    {count === 0 && (
                      <span className="text-[11px] text-white/30">قائمة فارغة — أضف مقاطع</span>
                    )}
                  </div>
                </button>
              );
            })}
            <button
              onClick={onManagePlaylists}
              className="rounded-2xl border-2 border-dashed border-white/10 text-white/40 hover:border-fuchsia-400/40 hover:text-fuchsia-300 transition grid place-items-center py-8 min-h-28"
            >
              <span className="flex flex-col items-center gap-2 text-sm font-bold">
                <Plus className="h-6 w-6" />
                قائمة جديدة
              </span>
            </button>
          </div>
        )
      ) : visible.length === 0 ? (
        <EmptyState
          icon={tab === "favs" ? Heart : tab === "history" ? History : Music2}
          title={
            search
              ? "لا توجد نتائج"
              : tab === "favs"
              ? "لا توجد مفضلة بعد"
              : tab === "history"
              ? "لا يوجد سجل استماع"
              : tab === "music"
              ? "لا توجد موسيقى"
              : tab === "video"
              ? "لا توجد فيديوهات"
              : "مكتبتك فارغة"
          }
          desc={
            search
              ? "جرّب كلمة بحث مختلفة"
              : tab === "favs"
              ? "اضغط على القلب ♥ لأي أغنية تحبها وستجدها هنا"
              : tab === "history"
              ? "المقاطع التي تستمع إليها ستظهر هنا تلقائيًا"
              : "افتح ملفاتك من هاتفك وستظهر هنا — كل شيء يعمل محليًا بدون إنترنت"
          }
          action={search || tab === "favs" || tab === "history" ? undefined : "فتح ملفات الوسائط"}
          onAction={openFiles}
        />
      ) : (
        <div className="space-y-2 anim-fade-up">
          {visible.map((t) => (
            <TrackCard
              key={t.id}
              track={t}
              isCurrent={p.current?.id === t.id}
              isPlaying={p.playing && p.current?.id === t.id}
              isFav={p.favs.includes(t.id)}
              onPlay={() => playList(visible.map((x) => x.id), t.id)}
              onFav={() => p.toggleFav(t.id)}
              onAdd={() => onAddToPlaylist(t.id)}
              onDelete={() => p.removeTrack(t.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
