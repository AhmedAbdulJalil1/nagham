import {
  Heart,
  Music2,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
  Timer,
  Volume2,
  VolumeX,
} from "lucide-react";
import { usePlayer } from "../player/PlayerContext";
import { artGradient, formatTime } from "../lib/utils";
import RangeSlider from "./RangeSlider";

export default function PlayerBar({
  onOpenNowPlaying,
  onOpenEq,
  onOpenSleep,
}: {
  onOpenNowPlaying: () => void;
  onOpenEq: () => void;
  onOpenSleep: () => void;
}) {
  const p = usePlayer();
  const c = p.current;
  if (!c) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 px-2 pb-safe">
      <div className="mx-auto max-w-6xl rounded-t-3xl md:rounded-3xl md:mb-3 glass border-white/10 bg-[#0d0d17]/90 shadow-2xl shadow-black/60 overflow-hidden">
        {/* شريط التقدم */}
        <div className="px-3 pt-1.5 flex items-center gap-2">
          <span className="text-[10px] tabular-nums text-white/45 w-10 text-left" dir="ltr">
            {formatTime(p.time)}
          </span>
          <RangeSlider
            className="flex-1"
            small
            value={p.time}
            max={p.duration || 1}
            step={0.1}
            onChange={p.seek}
          />
          <span className="text-[10px] tabular-nums text-white/45 w-10" dir="ltr">
            {formatTime(p.duration)}
          </span>
        </div>

        <div className="flex items-center gap-2 px-3 pb-2.5 pt-1">
          {/* المقطع الحالي */}
          <button onClick={onOpenNowPlaying} className="flex items-center gap-3 flex-1 min-w-0 text-right">
            {c.type === "audio" ? (
              <div
                className="h-11 w-11 shrink-0 rounded-xl grid place-items-center shadow-lg"
                style={{ background: artGradient(c.name) }}
              >
                <Music2 className="h-5 w-5 text-white/90" />
              </div>
            ) : c.thumbnail ? (
              <img src={c.thumbnail} alt="" className="h-11 w-[70px] shrink-0 rounded-xl object-cover" />
            ) : (
              <div className="h-11 w-[70px] shrink-0 rounded-xl grid place-items-center bg-gradient-to-br from-violet-600 to-fuchsia-600">
                <Music2 className="h-5 w-5 text-white/90" />
              </div>
            )}
            <span className="min-w-0">
              <span className="block truncate text-[13px] font-bold">{c.name}</span>
              <span className="block text-[10px] text-white/40 mt-0.5">
                {c.type === "audio" ? "موسيقى" : "فيديو"} • {formatTime(c.duration || p.duration)}
              </span>
            </span>
          </button>

          {/* مؤقت النوم */}
          {p.sleepEnd && (
            <button
              onClick={onOpenSleep}
              className="hidden sm:flex items-center gap-1 rounded-full bg-amber-500/15 text-amber-300 text-[10px] font-bold px-2.5 py-1.5"
            >
              <Timer className="h-3 w-3" />
              {p.sleepRemaining} د
            </button>
          )}

          {/* المعادل الصوتي */}
          <button
            onClick={onOpenEq}
            className={`hidden sm:grid place-items-center h-9 w-9 rounded-xl transition ${
              p.eqOn ? "bg-fuchsia-500/25 text-fuchsia-300" : "text-white/50 hover:bg-white/5"
            }`}
            title="المعادل الصوتي"
          >
            <SlidersHorizontal className="h-4.5 w-4.5" />
          </button>

          {/* المفضلة */}
          <button
            onClick={() => p.toggleFav(c.id)}
            className={`grid place-items-center h-9 w-9 rounded-xl transition ${
              p.favs.includes(c.id) ? "text-rose-400" : "text-white/50 hover:bg-white/5"
            }`}
          >
            <Heart className={`h-4.5 w-4.5 ${p.favs.includes(c.id) ? "fill-rose-400" : ""}`} />
          </button>

          {/* أزرار التحكم */}
          <div className="flex items-center gap-0.5 sm:gap-1.5">
            <button
              onClick={p.toggleShuffle}
              className={`grid place-items-center h-9 w-9 rounded-xl transition ${
                p.shuffle ? "text-fuchsia-300 bg-fuchsia-500/15" : "text-white/50 hover:bg-white/5"
              }`}
              title="تشغيل عشوائي"
            >
              <Shuffle className="h-4 w-4" />
            </button>
            <button
              onClick={p.prev}
              className="grid place-items-center h-10 w-10 rounded-xl text-white hover:bg-white/5"
            >
              <SkipBack className="h-5 w-5 fill-current" />
            </button>
            <button
              onClick={p.playPause}
              className="grid place-items-center h-12 w-12 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-lg shadow-fuchsia-600/40 active:scale-95 transition"
            >
              {p.playing ? (
                <Pause className="h-6 w-6 fill-white" />
              ) : (
                <Play className="h-6 w-6 fill-white pr-0.5" />
              )}
            </button>
            <button
              onClick={() => p.next()}
              className="grid place-items-center h-10 w-10 rounded-xl text-white hover:bg-white/5"
            >
              <SkipForward className="h-5 w-5 fill-current" />
            </button>
            <button
              onClick={p.cycleRepeat}
              className={`grid place-items-center h-9 w-9 rounded-xl transition ${
                p.repeat !== "off" ? "text-fuchsia-300 bg-fuchsia-500/15" : "text-white/50 hover:bg-white/5"
              }`}
              title="تكرار"
            >
              {p.repeat === "one" ? <Repeat1 className="h-4 w-4" /> : <Repeat className="h-4 w-4" />}
            </button>
          </div>

          {/* الصوت + السرعة */}
          <div className="hidden lg:flex items-center gap-2 w-44">
            <button onClick={p.toggleMute} className="text-white/60 hover:text-white">
              {p.muted || p.volume === 0 ? <VolumeX className="h-4.5 w-4.5" /> : <Volume2 className="h-4.5 w-4.5" />}
            </button>
            <RangeSlider
              className="flex-1"
              small
              value={p.muted ? 0 : p.volume}
              max={1}
              step={0.01}
              onChange={p.setVolume}
            />
          </div>
          <button
            onClick={p.cycleSpeed}
            className="hidden md:grid place-items-center h-8 px-2 rounded-lg text-[11px] font-black text-white/60 hover:bg-white/5 tabular-nums"
            title="سرعة التشغيل"
          >
            {p.speed}×
          </button>
        </div>
      </div>
    </div>
  );
}
