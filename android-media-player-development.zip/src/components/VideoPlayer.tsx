import { useEffect, useRef, useState } from "react";
import {
  Maximize,
  Minimize,
  Pause,
  Play,
  SkipForward,
  X,
} from "lucide-react";
import { usePlayer } from "../player/PlayerContext";
import { formatTime } from "../lib/utils";
import RangeSlider from "./RangeSlider";

export default function VideoPlayer() {
  const p = usePlayer();
  const c = p.current;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const urlRef = useRef<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const hideTimer = useRef<number>(0);

  const isVideo = !!c && c.type === "video";

  /* تسجيل عنصر الفيديو في المحرك */
  useEffect(() => {
    p.registerVideoEl(isVideo ? videoRef.current : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isVideo]);

  /* تحميل المصدر عند تغيّر المقطع */
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !c || c.type !== "video") return;
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    const url = URL.createObjectURL(c.blob);
    urlRef.current = url;
    v.src = url;
    v.playbackRate = p.speed;
    v.volume = p.muted ? 0 : p.volume;
    if (p.playing) v.play().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [c?.id]);

  /* تنظيف عند الإغلاق */
  useEffect(() => {
    return () => {
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      p.registerVideoEl(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* مزامنة التشغيل/الإيقاف */
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !c || c.type !== "video") return;
    if (p.playing) v.play().catch(() => {});
    else v.pause();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.playing]);

  if (!isVideo || !c) return null;

  const showControls = () => {
    setControlsVisible(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => setControlsVisible(false), 2800);
  };

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else containerRef.current?.requestFullscreen().catch(() => {});
  };

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const close = () => {
    p.stop();
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[65] bg-black anim-fade flex flex-col"
      onPointerMove={showControls}
    >
      {/* الشريط العلوي */}
      <div
        className={`absolute top-0 inset-x-0 z-10 flex items-center justify-between px-4 pt-4 pb-8 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${
          controlsVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
          <span className="truncate text-sm font-bold text-white">{c.name}</span>
        </div>
        <button
          onClick={close}
          className="grid place-items-center h-10 w-10 rounded-full bg-white/10 text-white hover:bg-white/20"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* الفيديو */}
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        playsInline
        onClick={(e) => {
          e.stopPropagation();
          setControlsVisible((s) => !s);
        }}
        onTimeUpdate={(e) => p.syncVideo(e.currentTarget.currentTime, e.currentTarget.duration || 0)}
        onLoadedMetadata={(e) => p.syncVideo(0, e.currentTarget.duration || 0)}
        onEnded={p.onVideoEnded}
      />

      {/* شريط التحكم السفلي */}
      <div
        className={`absolute bottom-0 inset-x-0 z-10 px-4 pb-5 pt-10 bg-gradient-to-t from-black/85 to-transparent transition-opacity duration-300 ${
          controlsVisible ? "opacity-100" : "opacity-0"
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="text-[11px] tabular-nums text-white/70 w-11" dir="ltr">
            {formatTime(p.time)}
          </span>
          <RangeSlider
            className="flex-1"
            small
            value={p.time}
            max={p.duration || 1}
            step={0.1}
            onChange={p.seek}
          />
          <span className="text-[11px] tabular-nums text-white/70 w-11" dir="ltr">
            {formatTime(p.duration)}
          </span>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              p.playPause();
            }}
            className="grid place-items-center h-11 w-11 rounded-full bg-white text-black"
          >
            {p.playing ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current pr-0.5" />}
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              p.next();
            }}
            className="grid place-items-center h-10 w-10 rounded-full text-white/80 hover:bg-white/10"
          >
            <SkipForward className="h-5 w-5 fill-current" />
          </button>
          <span className="text-[11px] font-bold text-white/60 mx-1 truncate flex-1">{c.name}</span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              p.cycleSpeed();
            }}
            className="text-[11px] font-black text-white/70 px-2.5 py-1.5 rounded-lg hover:bg-white/10 tabular-nums"
          >
            {p.speed}×
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleFullscreen();
            }}
            className="grid place-items-center h-10 w-10 rounded-full text-white/80 hover:bg-white/10"
          >
            {fullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </div>
  );
}
