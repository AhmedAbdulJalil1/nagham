import { useState } from "react";
import {
  ChevronDown,
  Heart,
  ListMusic,
  ListPlus,
  Music2,
  Pause,
  Play,
  Repeat,
  Repeat1,
  Shuffle,
  SkipBack,
  SkipForward,
  SlidersHorizontal,
  Timer,
  X,
} from "lucide-react";
import { usePlayer } from "../player/PlayerContext";
import { artGradient, formatBytes, formatTime } from "../lib/utils";
import RangeSlider from "./RangeSlider";
import VisualizerCanvas from "./VisualizerCanvas";

export default function NowPlaying({
  onClose,
  onOpenEq,
  onOpenSleep,
  onAddToPlaylist,
}: {
  onClose: () => void;
  onOpenEq: () => void;
  onOpenSleep: () => void;
  onAddToPlaylist: (trackId: string) => void;
}) {
  const p = usePlayer();
  const c = p.current;
  const [showQueue, setShowQueue] = useState(false);
  if (!c || c.type !== "audio") return null;

  const queueTracks = p.queue
    .map((id) => p.tracks.find((t) => t.id === id))
    .filter((t): t is NonNullable<typeof t> => Boolean(t));

  return (
    <div className="fixed inset-0 z-[60] overflow-y-auto bg-[#07070d] anim-fade">
      {/* خلفية متوهجة */}
      <div
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full opacity-25 blur-3xl"
        style={{ background: artGradient(c.name) }}
      />
      <VisualizerCanvas
        analyser={p.analyser}
        active={p.playing}
        bars={48}
        className="absolute bottom-0 inset-x-0 h-40 opacity-30 pointer-events-none"
      />

      <div className="relative mx-auto max-w-md px-6 pb-10 pt-4 min-h-full flex flex-col">
        {/* الرأس */}
        <div className="flex items-center justify-between">
          <button
            onClick={onClose}
            className="grid place-items-center h-10 w-10 rounded-full glass text-white/70 hover:text-white"
          >
            <ChevronDown className="h-5 w-5" />
          </button>
          <div className="text-center">
            <p className="text-[11px] text-white/40 font-bold">الآن يُشغَّل</p>
            <p className="text-xs font-black text-fuchsia-300">من مكتبتك المحلية</p>
          </div>
          <button
            onClick={() => setShowQueue((s) => !s)}
            className={`grid place-items-center h-10 w-10 rounded-full glass ${
              showQueue ? "text-fuchsia-300" : "text-white/70 hover:text-white"
            }`}
          >
            <ListMusic className="h-5 w-5" />
          </button>
        </div>

        {/* القرص الدوّار */}
        <div className="flex-1 flex flex-col items-center justify-center py-6">
          <div className="relative anim-float">
            <div
              className={`absolute -inset-5 rounded-full opacity-70 anim-spin-slow ${p.playing ? "" : "spin-paused"}`}
              style={{
                background:
                  "conic-gradient(from 0deg, #7c3aed, #d946ef, #f59e0b, #ec4899, #7c3aed)",
              }}
            />
            <div className="absolute -inset-5 rounded-full bg-[#07070d]" style={{ inset: "-13px" }} />
            <div
              className={`relative h-60 w-60 sm:h-64 sm:w-64 rounded-full grid place-items-center ring-4 ring-white/10 anim-glow ${
                p.playing ? "" : "anim-glow"
              }`}
              style={{ background: artGradient(c.name) }}
            >
              <Music2 className="h-24 w-24 text-white/25" />
            </div>
          </div>

          <div className="mt-12 text-center w-full">
            <h2 className="text-2xl font-black truncate">{c.name}</h2>
            <p className="mt-1.5 text-sm text-white/45 font-semibold">
              {c.type === "audio" ? "موسيقى" : "فيديو"} • {formatBytes(c.size)} •{" "}
              {formatTime(c.duration || p.duration)}
            </p>
          </div>
        </div>

        {/* شريط التقدم */}
        <div className="flex items-center gap-3">
          <span className="text-xs tabular-nums text-white/50 w-11" dir="ltr">
            {formatTime(p.time)}
          </span>
          <RangeSlider
            className="flex-1"
            value={p.time}
            max={p.duration || 1}
            step={0.1}
            onChange={p.seek}
          />
          <span className="text-xs tabular-nums text-white/50 w-11" dir="ltr">
            {formatTime(p.duration)}
          </span>
        </div>

        {/* أزرار التحكم */}
        <div className="mt-5 flex items-center justify-center gap-2 sm:gap-4">
          <button
            onClick={p.toggleShuffle}
            className={`grid place-items-center h-11 w-11 rounded-2xl transition ${
              p.shuffle ? "text-fuchsia-300 bg-fuchsia-500/15" : "text-white/50 hover:bg-white/10"
            }`}
          >
            <Shuffle className="h-5 w-5" />
          </button>
          <button
            onClick={p.prev}
            className="grid place-items-center h-14 w-14 rounded-2xl text-white hover:bg-white/10"
          >
            <SkipBack className="h-7 w-7 fill-current" />
          </button>
          <button
            onClick={p.playPause}
            className="grid place-items-center h-[72px] w-[72px] rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-2xl shadow-fuchsia-600/40 active:scale-95 transition"
          >
            {p.playing ? (
              <Pause className="h-9 w-9 fill-white" />
            ) : (
              <Play className="h-9 w-9 fill-white pr-1" />
            )}
          </button>
          <button
            onClick={() => p.next()}
            className="grid place-items-center h-14 w-14 rounded-2xl text-white hover:bg-white/10"
          >
            <SkipForward className="h-7 w-7 fill-current" />
          </button>
          <button
            onClick={p.cycleRepeat}
            className={`grid place-items-center h-11 w-11 rounded-2xl transition ${
              p.repeat !== "off" ? "text-fuchsia-300 bg-fuchsia-500/15" : "text-white/50 hover:bg-white/10"
            }`}
          >
            {p.repeat === "one" ? <Repeat1 className="h-5 w-5" /> : <Repeat className="h-5 w-5" />}
          </button>
        </div>

        {/* الصف السفلي */}
        <div className="mt-6 flex items-center justify-center gap-2 flex-wrap">
          <button
            onClick={() => p.toggleFav(c.id)}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
              p.favs.includes(c.id)
                ? "bg-rose-500/15 text-rose-300"
                : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            <Heart className={`h-4 w-4 ${p.favs.includes(c.id) ? "fill-rose-400" : ""}`} />
            {p.favs.includes(c.id) ? "في المفضلة" : "أضف للمفضلة"}
          </button>
          <button
            onClick={() => onAddToPlaylist(c.id)}
            className="flex items-center gap-1.5 rounded-xl bg-white/5 px-3.5 py-2 text-xs font-bold text-white/60 hover:bg-white/10"
          >
            <ListPlus className="h-4 w-4" />
            أضف لقائمة
          </button>
          <button
            onClick={onOpenEq}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
              p.eqOn ? "bg-fuchsia-500/15 text-fuchsia-300" : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            <SlidersHorizontal className="h-4 w-4" />
            المعادل
          </button>
          <button
            onClick={p.cycleSpeed}
            className="rounded-xl bg-white/5 px-3.5 py-2 text-xs font-black text-white/60 hover:bg-white/10 tabular-nums"
          >
            {p.speed}×
          </button>
          <button
            onClick={onOpenSleep}
            className={`flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-bold transition ${
              p.sleepEnd ? "bg-amber-500/15 text-amber-300" : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            <Timer className="h-4 w-4" />
            {p.sleepEnd ? `${p.sleepRemaining} د` : "مؤقّت"}
          </button>
        </div>

        {/* قائمة التشغيل */}
        {showQueue && (
          <div className="mt-6 glass rounded-2xl overflow-hidden anim-fade-up">
            <div className="px-4 py-3 text-sm font-black border-b border-white/5 flex items-center justify-between">
              <span>قائمة التشغيل</span>
              <span className="text-[11px] text-white/40">{queueTracks.length} مقطع</span>
            </div>
            <div className="max-h-56 overflow-y-auto">
              {queueTracks.map((t, i) => (
                <button
                  key={t.id}
                  onClick={() => p.playFrom(p.queue, t.id)}
                  className={`w-full flex items-center gap-3 px-4 py-2.5 text-right transition ${
                    t.id === c.id ? "bg-fuchsia-500/10 text-fuchsia-300" : "hover:bg-white/5 text-white/75"
                  }`}
                >
                  <span className="text-[10px] w-5 text-white/35 tabular-nums">{i + 1}</span>
                  <span className="truncate text-[13px] font-bold flex-1">{t.name}</span>
                  <span className="text-[10px] text-white/35 tabular-nums" dir="ltr">
                    {formatTime(t.duration || 0)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="h-6" />
      </div>

      {/* زر إغلاق إضافي */}
      <button
        onClick={onClose}
        className="absolute top-4 left-4 grid place-items-center h-9 w-9 rounded-full glass text-white/50 hover:text-white"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
