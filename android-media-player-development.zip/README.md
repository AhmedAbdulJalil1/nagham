# 🎵 نغم — تطبيق أندرويد حقيقي (APK) من ملف مضغوط

مشغّل موسيقى وفيديو احترافي يعمل **محليًا على هاتفك 100% بدون إنترنت**.
تُرفع ملفات المشروع **مضغوطة في ملف ZIP واحد**، وGitHub Actions يفكّها ويبني لك **APK حقيقي** تثبّته على هاتفك — بدون حاسوب وبدون أندرويد ستوديو.

---

## ✨ الميزات الاحترافية

- 📡 **فحص تلقائي كامل للهاتف عند الفتح** — يكتشف كل ملفات الموسيقى والفيديو فورًا عبر MediaStore (سريع جدًا)
- 🎼 تشغيل الموسيقى والفيديو: MP3, M4A, FLAC, WAV, OGG, MP4, WEBM, MKV والمزيد
- 🎛️ معادل صوتي 10 نطاقات + 8 إعدادات مسبقة
- 🌈 مؤثرات بصرية حية تتحرك مع الموسيقى
- 🎬 مشغّل فيديو بملء الشاشة **بدون شريط إشعارات**
- 👆 إيماءات: نقرة مزدوجة ⏪⏩ للتقديم/التأخير، سحب يمين للصوت، سحب يسار للإضاءة، سحب أفقي للتنقل
- 🎧 **تشغيل في الخلفية** — شغّل الأغنية واخرج والعب والصوت مستمر
- 🔄 زر تدوير الشاشة + زر ملء الشاشة + زر السرعة (0.5× – 2×)
- ◀️▶️ أزرار السابق/التالي على جانبي شاشة الفيديو
- 📚 مكتبة ذكية: بحث فوري، فرز متعدد (الأحدث، الاسم، الحجم، المدة، تاريخ التعديل)، تبويبات
- 📁 قوائم تشغيل ومفضلة وسجل استماع محفوظة محليًا
- ⏰ مؤقّت نوم، تشغيل عشوائي وتكرار
- 🔋 يعمل بدون إنترنت تمامًا

---

## 🚀 الخطوات الكاملة — من هاتفك فقط

### المرحلة 1: تحميل المشروع مضغوطًا
1. من المنصة التي بنيت فيها المشروع اضغط زر **تحميل / Download** بصيغة **ZIP**
2. تأكد أن الملف المضغوط **لا يحتوي مجلد node_modules** (المجلد الضخم)

### المرحلة 2: إنشاء حساب GitHub (إن لم يكن لديك)
1. افتح متصفح كروم ← **github.com** ← **Sign up**
2. بريدك ← كلمة مرور ← اسم المستخدم ← تحقق ← خطة **Free**

### المرحلة 3: إنشاء المستودع ورفع الملف المضغوط
1. زر **+** ← **New repository** ← الاسم `nagham` ← ✅ **Public** ← **Create repository**
2. **Add file** ← **Upload files** ← ارفع ملف `nagham.zip` ← **Commit changes**

### المرحلة 4: إنشاء ملف مصنع البناء ⭐ (مرة واحدة فقط)
1. **Add file** ← **Create new file**
2. في خانة الاسم اكتب بالضبط: `.github/workflows/build-apk.yml`
   *(انتبه: `.github` بنقطة في البداية، و`workflows` بحرف s في النهاية)*
3. الصق **الكود كاملًا** من قسم "كود مصنع البناء" بالأسفل ← **Commit changes**

### المرحلة 5: تشغيل البناء والانتظار (10-25 دقيقة)
1. افتح تبويب **Actions** في مستودعك
2. ستجد "بناء تطبيق أندرويد" في القائمة الجانبية
3. إذا لم يبدأ تلقائيًا: اضغط على اسمه ← زر **Run workflow** ← **Run workflow** (تشغيل يدوي)
4. انتظر حتى ✅ خضراء — إذا ظهرت ❌ اضغط الخطوة الحمراء وقلّدني السطر الأخير

### المرحلة 6: تحميل الـ APK وتثبيته ⭐
1. تبويب **Releases** ← "نغم — تطبيق أندرويد" ← اضغط `nagham.apk`
2. افتح الملف ← **اسمح بالتثبيت من مصادر غير معروفة** ← **تثبيت**
3. افتح تطبيق **نغم** ← **اسمح بإذن الوصول لملفات الوسائط** ← سيبدأ الفحص التلقائي

### المرحلة 7: أول استخدام
- التطبيق **يفحص هاتفك تلقائيًا** ويعرض كل أغانيك وفيديوهاتك مرتبة
- عدّل الترتيب من قائمة الفرز (الأحدث، الاسم، الحجم، المدة...)
- شغّل أي مقطع وجرّب الإيماءات: نقرة مزدوجة ⏪⏩، سحب يمين للصوت، سحب يسار للإضاءة

### المرحلة 8: التحديثات المستقبلية
1. ارفع `nagham.zip` الجديد (بنفس الاسم) ← **Commit changes**
2. البناء يتكرر تلقائيًا ← حمّل الـ APK الجديد من Releases

---

## 🆘 المشكلة الأهم: "الورك فلو لا يبدأ إطلاقًا!"

إذا لم يبدأ البناء من الأساس، هذا أحد الأسباب التالية — راجعها بالترتيب:

| # | السبب | الحل |
|---|---|---|
| 1 | **الملف غير صالح (Invalid workflow file)** — لصقت كودًا كبيرًا فانكسرت مسافاته عند النسخ من الهاتف | احذف الملف وأنشئه من جديد بالكود **القصير** الموجود بالأسفل — صممته بحيث لا يحتوي أي كود مدمج كبير يمكن أن ينكسر |
| 2 | **المستودع خاص (Private)** — GitHub يوقف Actions تلقائيًا للمستودعات الخاصة | غيّر المستودع إلى **Public** (Settings ← General ← Danger Zone) أو فعّل: Settings ← Actions ← General ← **Allow all actions** |
| 3 | **اسم الفرع مختلف** — المشروع القديم يستخدم `master` وليس `main` | الكود الجديد يعمل مع **الاثنين معًا** (`main` و`master`) |
| 4 | **اسم الملف خاطئ** | تأكد أنه بالضبط: `.github/workflows/build-apk.yml` — لو كتبته `build_apk.yml` أو `workflow/` لن يعمل أبدًا |
| 5 | **لا يوجد زر تشغيل يدوي** | الكود الجديد يتضمن **Run workflow** — افتح Actions ← اختر "بناء تطبيق أندرويد" ← زر **Run workflow** باليمين |
| 6 | **البناء يعمل لكنه يفشل بسرعة** | هذا ليس "لا يبدأ" — اضغط على التشغيل الحمراء واقرأ السطر الأخير وقلّدني إياه |

**كيف تتأكد أن الملف سليم؟**
- افتح تبويب **Actions** — إذا رأيت شريطًا أحمر/أصفر أعلى الصفحة مكتوبًا فيه *"Invalid workflow file"* → ملفك غير صالح → احذفه وأعد إنشاءه بالكود القصير
- إذا رأيت "بناء تطبيق أندرويد" في القائمة الجانبية → الملف سليم ✅ → اضغط **Run workflow**

---

## 📜 كود مصنع البناء — قصير وآمن (انسخه كاملًا)

```yaml
name: بناء تطبيق أندرويد

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60

    steps:
      - uses: actions/checkout@v4

      - name: فك ضغط الملف المضغوط
        run: |
          ZIP=$(find . -maxdepth 3 -type f -name "*.zip" | head -1 || true)
          if [ -n "$ZIP" ]; then
            mkdir -p _unzip
            unzip -o "$ZIP" -d _unzip
            if [ -f _unzip/index.html ]; then
              SRC="_unzip"
            else
              SRC="$(find _unzip -name index.html -not -path "*/node_modules/*" | head -1 | xargs dirname 2>/dev/null || echo _unzip)"
            fi
            shopt -s dotglob
            cp -r "$SRC"/* . 2>/dev/null || true
            shopt -u dotglob
            rm -rf _unzip
            find . -maxdepth 3 -type f -name "*.zip" -delete
          fi
          test -f index.html && test -f package.json

      - name: تنظيف
        run: rm -rf node_modules dist android || true

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "21"

      - uses: android-actions/setup-android@v3

      - uses: actions/setup-node@v4
        with:
          node-version: "20"

      - name: تثبيت الحزم
        run: npm install --no-audit --no-fund

      - name: بناء الواجهة
        run: npm run build

      - name: توليد مشروع أندرويد
        run: |
          test -f capacitor.config.json || echo '{"appId":"com.nagham.app","appName":"نغم","webDir":"dist","backgroundColor":"#08080f"}' > capacitor.config.json
          npx cap add android
          npx cap sync android

      - name: تثبيت الفاحص الأصلي والأيقونة
        run: |
          mkdir -p android/app/src/main/java/com/nagham/app
          cp native/MediaScannerPlugin.java android/app/src/main/java/com/nagham/app/
          cp native/MainActivity.java android/app/src/main/java/com/nagham/app/
          MANIFEST=android/app/src/main/AndroidManifest.xml
          grep -q "READ_MEDIA_AUDIO" "$MANIFEST" || sed -i 's#</manifest>#<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n</manifest>#' "$MANIFEST"
          ICON=""
          [ -f public/icon-512.png ] && ICON="public/icon-512.png"
          [ -z "$ICON" ] && [ -f icon-512.png ] && ICON="icon-512.png"
          if [ -n "$ICON" ]; then
            sudo apt-get update -qq || true
            sudo apt-get install -y -qq imagemagick || true
            for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
              case $d in
                mdpi) s=48;; hdpi) s=72;; xhdpi) s=96;; xxhdpi) s=144;; xxxhdpi) s=192;;
              esac
              mkdir -p android/app/src/main/res/mipmap-$d
              convert "$ICON" -resize ${s}x${s} android/app/src/main/res/mipmap-$d/ic_launcher.png || true
            done
            rm -f android/app/src/main/res/drawable-v24/ic_launcher_foreground.xml
          fi
          echo "تم التثبيت بنجاح"

      - name: بناء ملف APK
        working-directory: android
        run: ./gradlew assembleDebug

      - name: تسمية الملف النهائي
        run: cp android/app/build/outputs/apk/debug/app-debug.apk nagham.apk

      - uses: actions/upload-artifact@v4
        with:
          name: nagham-apk
          path: nagham.apk

      - name: حذف الإصدار القديم
        env:
          GH_TOKEN: ${{ github.token }}
        run: gh release delete nagham-latest --yes --cleanup-tag --repo ${{ github.repository }} || true

      - name: نشر الإصدار الجديد
        uses: softprops/action-gh-release@v2
        with:
          tag_name: nagham-latest
          name: نغم — تطبيق أندرويد
          body: |
            📲 أحدث نسخة من تطبيق نغم

            حمّل nagham.apk وافتحه على هاتفك لتثبيته مباشرة.
            - فحص تلقائي لكل ملفات الهاتف عند الفتح
            - معادل صوتي + مؤثرات بصرية + قوائم تشغيل
            - فيديو بملء الشاشة + إيماءات + تشغيل في الخلفية
          files: nagham.apk
          draft: false
          prerelease: false
```

---

## ⚠️ حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| "Invalid workflow file" شريط أحمر | الملف غير صالح → احذفه وأعد إنشاءه بالكود القصير أعلاه |
| البناء لا يبدأ بعد الرفع | استخدم زر **Run workflow** يدويًا من تبويب Actions |
| التطبيق يطلب إذن الملفات | اسمح — ضروري للفحص التلقائي |
| الفحص لا يجد ملفات | تأكد من الإذن + أن الملفات في الذاكرة الداخلية |
| "التثبيت محظور" | الإعدادات ← الأمان ← مصادر غير معروفة ← اسمح |
| تحديث لا يُثبَّت فوق القديم | ألغِ تثبيت القديم ثم ثبّت الجديد |

---

*نغم v2.1 — صُنع بحب 🎵*
