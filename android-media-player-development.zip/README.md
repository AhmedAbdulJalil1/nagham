# 🎵 نغم — تطبيق أندرويد حقيقي (APK) من ملف مضغوط واحد

مشغّل موسيقى وفيديو احترافي يعمل **محليًا على هاتفك 100% بدون إنترنت**.
تُرفع ملفات المشروع **مضغوطة في ملف ZIP واحد**، وGitHub يفكّ الضغط ويبني لك **APK حقيقي** تثبّته على هاتفك — بدون حاسوب وبدون أندرويد ستوديو.

---

## 💡 لماذا طريقة الملف المضغوط؟

| | رفع ملف ملف | رفع ملف مضغوط واحد ✅ |
|---|---|---|
| عدد خطوات الرفع | 4-5 مرات | مرة واحدة |
| احتمال نسيان ملف | موجود | صفر (كل شيء داخل ZIP) |
| أخطاء أسماء الملفات | ممكنة | مستحيلة |
| مصنع البناء | تحتاج إنشاءه يدويًا | **داخل ZIP نفسه** |

---

## 🚀 الخطوات الكاملة — من هاتفك فقط

### المرحلة 1: تحميل المشروع مضغوطًا
1. من المنصة التي بنيت فيها المشروع اضغط زر **تحميل / Download / تصدير** بصيغة **ZIP**
2. سيُحمّل ملف مثل: `nagham.zip` — يحتوي على **كل شيء**:
   - `index.html` + `src/` (كود التطبيق)
   - `.github/workflows/build-apk.yml` ← **مصنع البناء (موجود بداخله!)**
   - `public/` (الأيقونة وملفات التطبيق)
3. ⚠️ **تأكد أن الملف المضغوط لا يحتوي مجلد `node_modules`** (المجلد الضخم) — أغلب منصات التحميل تحذفه تلقائيًا. إن وُجد بداخله، أعِد التحميل أو احذفه قبل الرفع

### المرحلة 2: إنشاء حساب GitHub (إن لم يكن لديك)
1. افتح متصفح كروم ← **github.com** ← **Sign up**
2. بريدك ← كلمة مرور (8 أحرف+) ← اسم المستخدم ← تحقق ورمز البريد
3. اختر الخطة **Free** (مجانية) ← **Skip** للأسئلة

### المرحلة 3: إنشاء المستودع
1. زر **+** ← **New repository**
2. الاسم: `nagham` ← ✅ اختر **Public** (مهم جدًا للبناء المجاني)
3. **Create repository**

### المرحلة 4: رفع الملف المضغوط ⭐ (الخطوة السحرية)
1. اضغط **Add file** ← **Upload files**
2. اضغط **choose your files** ← اختر ملف `nagham.zip` من هاتفك
3. **مهم:** GitHub سيعرض رسالة *"We'll unzip this file for you"* (سنفكّ الضغط عن هذا الملف) — هذا طبيعي ومطلوب! اضغط **Commit changes**
4. سيفكّ GitHub الضغط تلقائيًا ويرفع كل الملفات المفكوكة — بما فيها مصنع البناء

### المرحلة 5: التأكد من وجود مصنع البناء
1. من صفحة المستودع تصفح الملفات — تأكد من ظهور مجلد **`.github`** وبداخله `workflows/build-apk.yml`
2. **إذا كان موجودًا** ← ممتاز، تخطَّ إلى المرحلة 6
3. **إذا لم يكن موجودًا** (نادرًا) ← أنشئه يدويًا:
   - **Add file** ← **Create new file**
   - في خانة الاسم اكتب بالضبط: `.github/workflows/build-apk.yml`
   - الصق **الكود الكامل** من قسم "كود مصنع البناء" بالأسفل ← **Commit changes**
   - (هذا الرفع نفسه سيشغّل البناء!)

### المرحلة 6: انتظار البناء (10-25 دقيقة)
1. افتح تبويب **Actions** في مستودعك
2. ستجد مهمة "بناء تطبيق أندرويد" بدائرة صفراء (تعمل)
3. ⏳ انتظر حتى تتحول إلى ✅ خضراء
4. إذا ظهرت ❌ حمراء ← اضغط عليها وقلّدني أول خطأ تراه

### المرحلة 7: تحميل الـ APK وتثبيته ⭐
1. افتح تبويب **Releases** ← ستجد "نغم — تطبيق أندرويد"
2. اضغط **nagham.apk** ← سيُحمّل على هاتفك
3. افتح الملف من إشعارات الهاتف ← سيطلب أندرويد **السماح بالتثبيت من مصادر غير معروفة** ← **اسمح** ← **تثبيت**
4. افتح تطبيق **نغم** من شاشتك — تطبيق أندرويد حقيقي بأيقونته الخاصة! 🎉

### المرحلة 8: أول استخدام
1. اضغط **"فتح ملفات الوسائط"** ← منتقي ملفات أندرويد الرسمي سيظهر
2. اختر أغانيك وفيديوهاتك من ذاكرة هاتفك (اسمح بصلاحية الوصول للملفات عند الطلب)
3. استمتع! 🎧 معادل صوتي، مؤثرات بصرية، قوائم تشغيل، فيديو بملء الشاشة — **بدون إنترنت نهائيًا**

### المرحلة 9: التحديثات المستقبلية
**الطريقة السهلة:** عدّل ملف `index.html` الجديد وارفعه مضغوطًا بنفس الطريقة، أو ارفعه منفردًا بنفس الاسم (سيستبدل القديم) ← البناء يعمل تلقائيًا ← حمّل الـ APK الجديد من Releases.
*(ملاحظة: قد يُطلب منك إلغاء تثبيت النسخة القديمة قبل تثبيت الجديدة لأن التوقيع يتغير مع كل بناء)*

---

## 📜 كود مصنع البناء (للصقه يدويًا إذا احتجت)

```yaml
name: بناء تطبيق أندرويد

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60

    steps:
      - name: تحميل ملفات المشروع
        uses: actions/checkout@v4

      - name: فك ضغط الملف المضغوط تلقائيًا
        run: |
          set -e
          if [ ! -f index.html ]; then
            ZIP=$(find . -maxdepth 3 -name "*.zip" | head -1 || true)
            if [ -n "$ZIP" ]; then
              echo "📦 تم العثور على ملف مضغوط: $ZIP — جاري فكّه..."
              mkdir -p _unzip
              unzip -o "$ZIP" -d _unzip
              if [ -f _unzip/index.html ]; then
                SRC="_unzip"
              else
                SRC="$(find _unzip -name index.html | head -1 | xargs dirname 2>/dev/null || echo _unzip)"
              fi
              shopt -s dotglob
              cp -r "$SRC"/* . 2>/dev/null || true
              shopt -u dotglob
              rm -rf _unzip "$ZIP"
            fi
          fi
          ls -la

      - name: تنظيف المجلدات القديمة
        run: rm -rf node_modules dist android || true

      - name: تثبيت Java 21
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "21"

      - name: تثبيت أدوات أندرويد
        uses: android-actions/setup-android@v3

      - name: تثبيت Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: "20"

      - name: تثبيت حزم المشروع
        run: npm install --no-audit --no-fund

      - name: تثبيت أدوات كاباستور
        run: npm install --no-audit --no-fund @capacitor/core@7 @capacitor/cli@7 @capacitor/android@7 @capacitor/app@7

      - name: بناء واجهة التطبيق
        run: npm run build

      - name: توليد مشروع أندرويد
        run: |
          if [ ! -f capacitor.config.json ]; then
            echo '{"appId":"com.nagham.app","appName":"نغم","webDir":"dist","backgroundColor":"#08080f"}' > capacitor.config.json
          fi
          npx cap add android

      - name: مزامنة ملفات التطبيق
        run: npx cap sync android

      - name: تركيب أيقونة نغم
        run: |
          ICON=""
          if [ -f public/icon-512.png ]; then ICON="public/icon-512.png"
          elif [ -f public/icons/icon-512.png ]; then ICON="public/icons/icon-512.png"
          elif [ -f icon-512.png ]; then ICON="icon-512.png"
          fi
          if [ -n "$ICON" ]; then
            sudo apt-get update -qq
            sudo apt-get install -y -qq imagemagick
            for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
              case $d in
                mdpi) s=48;; hdpi) s=72;; xhdpi) s=96;; xxhdpi) s=144;; xxxhdpi) s=192;;
              esac
              convert "$ICON" -resize ${s}x${s} android/app/src/main/res/mipmap-$d/ic_launcher.png
              cp android/app/src/main/res/mipmap-$d/ic_launcher.png android/app/src/main/res/mipmap-$d/ic_launcher_round.png
            done
            for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
              case $d in
                mdpi) s=108;; hdpi) s=162;; xhdpi) s=216;; xxhdpi) s=324;; xxxhdpi) s=432;;
              esac
              convert "$ICON" -resize ${s}x${s} android/app/src/main/res/drawable-$d/ic_launcher_foreground.png
            done
          fi

      - name: بناء ملف APK
        working-directory: android
        run: ./gradlew assembleDebug

      - name: تسمية الملف النهائي
        run: cp android/app/build/outputs/apk/debug/app-debug.apk nagham.apk

      - name: رفع الـ APK كمرفق
        uses: actions/upload-artifact@v4
        with:
          name: nagham-apk
          path: nagham.apk

      - name: حذف الإصدار القديم
        env:
          GH_TOKEN: ${{ github.token }}
        run: gh release delete nagham-latest --yes --cleanup-tag --repo ${{ github.repository }} || true

      - name: نشر الإصدار الجديد
        uses: softprops/action-gh-release@v2
        with:
          tag_name: nagham-latest
          name: نغم — تطبيق أندرويد
          body: |
            📲 أحدث نسخة من تطبيق نغم (مبنية من الملف المضغوط)

            حمّل ملف nagham.apk وافتحه على هاتفك لتثبيته مباشرة.
            - يعمل بدون إنترنت 100%
            - معادل صوتي + مؤثرات بصرية + قوائم تشغيل + فيديو بملء الشاشة
          files: nagham.apk
          draft: false
          prerelease: false
```

---

## ⚠️ حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| البناء ❌ فشل | اضغط الخطوة الحمراء واقرأ السطر الأخير، أو تأكد أن ملف ZIP لا يحتوي node_modules |
| البناء **لم يبدأ** تلقائيًا | مصنع البناء غير موجود → أنشئه يدويًا من الكود أعلاه (المرحلة 5) |
| الملف المضغوط رُفع كملف واحد ولم يُفك | لا مشكلة! مصنع البناء يفكّه بنفسه — فقط تأكد أن مصنع البناء موجود |
| "التثبيت محظور" على الهاتف | الإعدادات ← الأمان ← تثبيت تطبيقات غير معروفة ← اسمح للمتصفح أو مدير الملفات |
| الـ APK لا يظهر في Releases | انتظر انتهاء البناء ✅ أولًا ثم حدّث الصفحة |
| تحديث لا يُثبَّت فوق القديم | ألغِ تثبيت النسخة القديمة ثم ثبّت الجديدة |
| ZIP أكبر من 100MB | احذف node_modules وdist من داخل الملف المضغوط وأعد رفعه |

---

## ✨ ميزات التطبيق

- 🎼 تشغيل الموسيقى والفيديو: MP3, M4A, FLAC, WAV, OGG, MP4, WEBM, MKV والمزيد
- 🎛️ معادل صوتي 10 نطاقات + 8 إعدادات مسبقة (بوب، روك، جاز، باس قوي...)
- 🌈 مؤثرات بصرية حية تتحرك مع الموسيقى
- 📚 مكتبة ذكية: بحث فوري، فرز، تبويبات (الكل / موسيقى / فيديو / مفضلة / قوائم / سجل)
- 📁 قوائم تشغيل ومفضلة وسجل استماع — كلها محفوظة محليًا على جهازك
- 🎬 مشغّل فيديو بملء الشاشة مع صور مصغرة تلقائية
- ⏰ مؤقّت نوم، سرعات تشغيل (0.5× – 2×)، تشغيل عشوائي وتكرار
- 🔋 يعمل بدون إنترنت تمامًا — لا استهلاك بيانات

---

*نغم v1.0 — صُنع بحب 🎵*
