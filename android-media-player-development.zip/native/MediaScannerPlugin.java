package com.nagham.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;

@CapacitorPlugin(
    name = "MediaScanner",
    permissions = {
      @Permission(
          alias = "media",
          strings = {
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_EXTERNAL_STORAGE
          })
    })
public class MediaScannerPlugin extends Plugin {

  @PluginMethod
  public void requestPermissions(PluginCall call) {
    if (getPermissionState("media") == PermissionState.GRANTED) {
      JSObject ret = new JSObject();
      ret.put("granted", true);
      call.resolve(ret);
      return;
    }
    requestPermissionForAlias("media", call, "permissionCallback");
  }

  private void permissionCallback(PluginCall call) {
    boolean granted = getPermissionState("media") == PermissionState.GRANTED;
    JSObject ret = new JSObject();
    ret.put("granted", granted);
    call.resolve(ret);
  }

  @PluginMethod
  public void scan(PluginCall call) {
    if (getPermissionState("media") != PermissionState.GRANTED) {
      call.reject("PERMISSION_DENIED");
      return;
    }
    try {
      JSArray out = new JSArray();
      out.addAll(query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio"));
      out.addAll(query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video"));
      JSObject ret = new JSObject();
      ret.put("media", out);
      call.resolve(ret);
    } catch (Exception e) {
      call.reject("SCAN_FAILED: " + e.getMessage());
    }
  }

  private JSArray query(Uri collection, String type) {
    JSArray arr = new JSArray();
    ContentResolver cr = getContext().getContentResolver();
    String[] proj = {
      MediaStore.MediaColumns._ID,
      MediaStore.MediaColumns.DISPLAY_NAME,
      MediaStore.MediaColumns.SIZE,
      MediaStore.MediaColumns.DATE_MODIFIED,
      MediaStore.MediaColumns.DURATION,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ARTIST
    };
    Cursor cursor = null;
    try {
      cursor = cr.query(collection, proj, null, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC");
    } catch (Exception e) {
      return arr;
    }
    if (cursor == null) return arr;
    try {
      while (cursor.moveToNext()) {
        JSObject o = new JSObject();
        long id = cursor.getLong(0);
        o.put("id", String.valueOf(id));
        o.put("name", cursor.getString(1) == null ? "" : cursor.getString(1));
        o.put("size", cursor.getLong(2));
        o.put("dateModified", cursor.getLong(3) * 1000L);
        o.put("duration", cursor.isNull(4) ? 0 : cursor.getLong(4));
        o.put("album", cursor.isNull(5) ? "" : cursor.getString(5));
        o.put("artist", cursor.isNull(6) ? "" : cursor.getString(6));
        o.put("uri", ContentUris.withAppendedId(collection, id).toString());
        o.put("type", type);
        arr.put(o);
      }
    } finally {
      cursor.close();
    }
    return arr;
  }
}
