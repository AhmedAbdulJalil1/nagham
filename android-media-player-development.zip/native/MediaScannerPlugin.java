package com.nagham.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;

@CapacitorPlugin(
    name = "MediaScanner",
    permissions = {
      @Permission(
          alias = "media",
          strings = {
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_EXTERNAL_STORAGE
          })
    })
public class MediaScannerPlugin extends Plugin {

  @PluginMethod
  public void requestPermissions(PluginCall call) {
    if (getPermissionState("media") == PermissionState.GRANTED) {
      JSObject ret = new JSObject();
      ret.put("granted", true);
      call.resolve(ret);
      return;
    }
    requestPermissionForAlias("media", call, "permissionCallback");
  }

  private void permissionCallback(PluginCall call) {
    boolean granted = getPermissionState("media") == PermissionState.GRANTED;
    JSObject ret = new JSObject();
    ret.put("granted", granted);
    call.resolve(ret);
  }

  @PluginMethod
  public void scan(PluginCall call) {
    if (getPermissionState("media") != PermissionState.GRANTED) {
      call.reject("PERMISSION_DENIED");
      return;
    }
    try {
      JSArray audio = query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio");
      JSArray video = query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video");
      JSArray out = new JSArray();
      for (int i = 0; i < audio.length(); i++) out.put(audio.get(i));
      for (int i = 0; i < video.length(); i++) out.put(video.get(i));
      JSObject ret = new JSObject();
      ret.put("media", out);
      call.resolve(ret);
    } catch (Exception e) {
      call.reject("SCAN_FAILED: " + e.getMessage());
    }
  }

  private JSArray query(Uri collection, String type) {
    JSArray arr = new JSArray();
    ContentResolver cr = getContext().getContentResolver();
    boolean isAudio = type.equals("audio");
    String[] proj;
    if (isAudio) {
      proj = new String[] {
        MediaStore.MediaColumns._ID,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DURATION,
        MediaStore.Audio.AudioColumns.ALBUM,
        MediaStore.Audio.AudioColumns.ARTIST
      };
    } else {
      proj = new String[] {
        MediaStore.MediaColumns._ID,
        MediaStore.MediaColumns.DISPLAY_NAME,
        MediaStore.MediaColumns.SIZE,
        MediaStore.MediaColumns.DATE_MODIFIED,
        MediaStore.MediaColumns.DURATION
      };
    }
    Cursor cursor = null;
    try {
      cursor = cr.query(collection, proj, null, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC");
    } catch (Exception e) {
      return arr;
    }
    if (cursor == null) return arr;
    try {
      int idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
      int nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
      int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
      int dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED);
      int durCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION);
      int albumCol = isAudio ? cursor.getColumnIndex(MediaStore.Audio.AudioColumns.ALBUM) : -1;
      int artistCol = isAudio ? cursor.getColumnIndex(MediaStore.Audio.AudioColumns.ARTIST) : -1;
      while (cursor.moveToNext()) {
        JSObject o = new JSObject();
        long id = cursor.getLong(idCol);
        o.put("id", String.valueOf(id));
        o.put("name", cursor.getString(nameCol) == null ? "" : cursor.getString(nameCol));
        o.put("size", cursor.getLong(sizeCol));
        o.put("dateModified", cursor.getLong(dateCol) * 1000L);
        o.put("duration", cursor.isNull(durCol) ? 0 : cursor.getLong(durCol));
        o.put("album", (albumCol >= 0 && !cursor.isNull(albumCol)) ? cursor.getString(albumCol) : "");
        o.put("artist", (artistCol >= 0 && !cursor.isNull(artistCol)) ? cursor.getString(artistCol) : "");
        o.put("uri", ContentUris.withAppendedId(collection, id).toString());
        o.put("type", type);
        arr.put(o);
      }
    } catch (Exception e) {
      // تجاهل أخطاء الصفوف الفردية
    } finally {
      cursor.close();
    }
    return arr;
  }
}
