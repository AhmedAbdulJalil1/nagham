# 🎵 نغم — تطبيق أندرويد حقيقي (APK) من ملف مضغوط

مشغّل موسيقى وفيديو احترافي يعمل **محليًا على هاتفك 100% بدون إنترنت**.
تُرفع ملفات المشروع **مضغوطة في ملف ZIP واحد**، وGitHub Actions يفكّها ويبني لك **APK حقيقي** تثبّته على هاتفك — بدون حاسوب وبدون أندرويد ستوديو.

---

## ✨ الميزات الاحترافية

- 📡 **فحص تلقائي كامل للهاتف عند الفتح** — يكتشف كل ملفات الموسيقى والفيديو فورًا عبر MediaStore (سريع جدًا حتى مع آلاف الملفات)
- 🎼 تشغيل الموسيقى والفيديو: MP3, M4A, FLAC, WAV, OGG, MP4, WEBM, MKV والمزيد
- 🎛️ معادل صوتي 10 نطاقات + 8 إعدادات مسبقة (بوب، روك، جاز، باس قوي...)
- 🌈 مؤثرات بصرية حية تتحرك مع الموسيقى
- 🎬 **مشغّل فيديو بملء الشاشة بدون شريط إشعارات** (يُخفى تلقائيًا)
- 👆 **إيماءات احترافية**:
  - نقرة مزدوجة يمين = ⏩ تقديم 10 ثوانٍ / نقرة مزدوجة يسار = ⏪ تأخير 10 ثوانٍ
  - سحب عمودي من **اليمين** = رفع/خفض الصوت
  - سحب عمودي من **اليسار** = رفع/خفض الإضاءة
  - سحب أفقي = تقديم/تأخير سريع
- 🎧 **زر التشغيل في الخلفية** — شغّل الأغنية واخرج من التطبيق والعب أو تصفح هاتفك والصوت مستمر
- 🔄 زر تدوير الشاشة (أفقي/عمودي) + زر ملء الشاشة + زر السرعة (0.5× – 2×)
- ◀️▶️ أزرار المقطع السابق/التالي على جانبي شاشة الفيديو
- 📚 مكتبة ذكية: بحث فوري، فرز (الأحدث، الأقدم، الاسم، الحجم، المدة، تاريخ التعديل)، تبويبات (الكل / موسيقى / فيديو / مفضلة / قوائم / سجل)
- 📁 قوائم تشغيل ومفضلة وسجل استماع — كلها محفوظة محليًا
- ⏰ مؤقّت نوم، تشغيل عشوائي وتكرار
- 🔋 يعمل بدون إنترنت تمامًا

---

## ⚠️ مهم: GitHub لا يفك ضغط ZIP تلقائيًا!

عند رفع ملف ZIP من الهاتف، GitHub يرفعه **كما هو** ولا يفكّه.
**لا مشكلة أبدًا!** مصنع البناء (ملف الأوامر) هو الذي يتولى فك الضغط — لكن يجب أن يكون موجودًا في المستودع.

> **الحل:** أنشئ ملف مصنع البناء يدويًا مرة واحدة (المرحلة 4 بالأسفل) — وسيتولى هو فكّ ZIP وبناء APK تلقائيًا.

---

## 🚀 الخطوات الكاملة — من هاتفك فقط

### المرحلة 1: تحميل المشروع مضغوطًا
1. من المنصة التي بنيت فيها المشروع اضغط زر **تحميل / Download** بصيغة **ZIP**
2. تأكد أن الملف المضغوط **لا يحتوي مجلد node_modules** (المجلد الضخم)

### المرحلة 2: إنشاء حساب GitHub (إن لم يكن لديك)
1. افتح متصفح كروم ← **github.com** ← **Sign up**
2. بريدك ← كلمة مرور ← اسم المستخدم ← تحقق ← خطة **Free**

### المرحلة 3: إنشاء المستودع ورفع الملف المضغوط
1. زر **+** ← **New repository** ← الاسم `nagham` ← ✅ **Public** ← **Create repository**
2. **Add file** ← **Upload files** ← ارفع ملف `nagham.zip` ← **Commit changes**

### المرحلة 4: إنشاء ملف مصنع البناء ⭐ (مرة واحدة فقط)
1. **Add file** ← **Create new file**
2. في خانة الاسم اكتب بالضبط: `.github/workflows/build-apk.yml`
3. الصق **الكود كاملًا** من قسم "كود مصنع البناء" بالأسفل ← **Commit changes**
4. 🎉 لحظة الحفظ يبدأ البناء تلقائيًا!

### المرحلة 5: انتظار البناء (10-25 دقيقة)
1. افتح تبويب **Actions** ← مهمة "بناء تطبيق أندرويد" بدائرة صفراء
2. شاهد الخطوات: فك الضغط ← البناء ← **حقن الفاحص الأصلي** ← بناء APK
3. انتظر حتى ✅ خضراء — إذا ظهرت ❌ قلّدني السطر الأخير من الخطأ

### المرحلة 6: تحميل الـ APK وتثبيته ⭐
1. تبويب **Releases** ← "نغم — تطبيق أندرويد" ← اضغط `nagham.apk`
2. افتح الملف ← **اسمح بالتثبيت من مصادر غير معروفة** ← **تثبيت**
3. افتح تطبيق **نغم** — سيطلب **إذن الوصول لملفات الوسائط** ← **اسمح** (ضروري للفحص التلقائي)

### المرحلة 7: أول استخدام
- التطبيق **يفحص هاتفك تلقائيًا** ويعرض كل أغانيك وفيديوهاتك مرتبة فورًا
- عدّل الترتيب من قائمة الفرز (الأحدث، الاسم، الحجم، المدة...)
- شغّل أي مقطع وجرّب الإيماءات: نقرة مزدوجة ⏪⏩، سحب يمين للصوت، سحب يسار للإضاءة
- استمتع! 🎧

### المرحلة 8: التحديثات المستقبلية
1. ارفع `nagham.zip` الجديد (بنفس الاسم) ← **Commit changes**
2. البناء يتكرر تلقائيًا ← حمّل الـ APK الجديد من Releases
3. *(قد يُطلب إلغاء تثبيت القديم أولًا لأن التوقيع يتغير مع كل بناء)*

---

## 📜 كود مصنع البناء — انسخه كاملًا والصقه

```yaml
name: بناء تطبيق أندرويد

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60

    steps:
      - name: تحميل ملفات المشروع
        uses: actions/checkout@v4

      - name: فك ضغط الملف المضغوط تلقائيًا
        run: |
          set -e
          ZIP=$(find . -maxdepth 3 -type f -name "*.zip" | head -1 || true)
          if [ -n "$ZIP" ]; then
            echo "📦 تم العثور على الملف المضغوط: $ZIP"
            mkdir -p _unzip
            unzip -o "$ZIP" -d _unzip
            if [ -f _unzip/index.html ]; then
              SRC="_unzip"
            else
              SRC="$(find _unzip -name index.html -not -path "*/node_modules/*" | head -1 | xargs dirname 2>/dev/null || echo _unzip)"
            fi
            shopt -s dotglob
            cp -r "$SRC"/* . 2>/dev/null || true
            shopt -u dotglob
            rm -rf _unzip
            find . -maxdepth 3 -type f -name "*.zip" -delete
          fi
          if [ ! -f index.html ] || [ ! -f package.json ]; then
            echo "❌ ملفات المشروع غير موجودة بعد فك الضغط!"
            exit 1
          fi
          echo "✅ ملفات المشروع موجودة"

      - name: تنظيف المجلدات القديمة
        run: rm -rf node_modules dist android || true

      - name: تثبيت Java 21
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "21"

      - name: تثبيت أدوات أندرويد
        uses: android-actions/setup-android@v3

      - name: تثبيت Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: "20"

      - name: تثبيت حزم المشروع
        run: npm install --no-audit --no-fund

      - name: بناء واجهة التطبيق
        run: npm run build

      - name: توليد مشروع أندرويد
        run: |
          if [ ! -f capacitor.config.json ]; then
            echo '{"appId":"com.nagham.app","appName":"نغم","webDir":"dist","backgroundColor":"#08080f"}' > capacitor.config.json
          fi
          npx cap add android

      - name: مزامنة ملفات التطبيق
        run: npx cap sync android

      - name: حقن الفاحص الأصلي ووضع ملء الشاشة
        run: |
          mkdir -p android/app/src/main/java/com/nagham/app
          cat > android/app/src/main/java/com/nagham/app/MediaScannerPlugin.java <<'JAVAEOF'
package com.nagham.app;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;

@CapacitorPlugin(
    name = "MediaScanner",
    permissions = {
      @Permission(
          alias = "media",
          strings = {
            Manifest.permission.READ_MEDIA_AUDIO,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_EXTERNAL_STORAGE
          })
    })
public class MediaScannerPlugin extends Plugin {

  @PluginMethod
  public void requestPermissions(PluginCall call) {
    if (getPermissionState("media") == PermissionState.GRANTED) {
      JSObject ret = new JSObject();
      ret.put("granted", true);
      call.resolve(ret);
      return;
    }
    requestPermissionForAlias("media", call, "permissionCallback");
  }

  private void permissionCallback(PluginCall call) {
    boolean granted = getPermissionState("media") == PermissionState.GRANTED;
    JSObject ret = new JSObject();
    ret.put("granted", granted);
    call.resolve(ret);
  }

  @PluginMethod
  public void scan(PluginCall call) {
    if (getPermissionState("media") != PermissionState.GRANTED) {
      call.reject("PERMISSION_DENIED");
      return;
    }
    try {
      JSArray out = new JSArray();
      out.addAll(query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio"));
      out.addAll(query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video"));
      JSObject ret = new JSObject();
      ret.put("media", out);
      call.resolve(ret);
    } catch (Exception e) {
      call.reject("SCAN_FAILED: " + e.getMessage());
    }
  }

  private JSArray query(Uri collection, String type) {
    JSArray arr = new JSArray();
    ContentResolver cr = getContext().getContentResolver();
    String[] proj = {
      MediaStore.MediaColumns._ID,
      MediaStore.MediaColumns.DISPLAY_NAME,
      MediaStore.MediaColumns.SIZE,
      MediaStore.MediaColumns.DATE_MODIFIED,
      MediaStore.MediaColumns.DURATION,
      MediaStore.Audio.Media.ALBUM,
      MediaStore.Audio.Media.ARTIST
    };
    Cursor cursor = null;
    try {
      cursor = cr.query(collection, proj, null, null, MediaStore.MediaColumns.DATE_MODIFIED + " DESC");
    } catch (Exception e) {
      return arr;
    }
    if (cursor == null) return arr;
    try {
      while (cursor.moveToNext()) {
        JSObject o = new JSObject();
        long id = cursor.getLong(0);
        o.put("id", String.valueOf(id));
        o.put("name", cursor.getString(1) == null ? "" : cursor.getString(1));
        o.put("size", cursor.getLong(2));
        o.put("dateModified", cursor.getLong(3) * 1000L);
        o.put("duration", cursor.isNull(4) ? 0 : cursor.getLong(4));
        o.put("album", cursor.isNull(5) ? "" : cursor.getString(5));
        o.put("artist", cursor.isNull(6) ? "" : cursor.getString(6));
        o.put("uri", ContentUris.withAppendedId(collection, id).toString());
        o.put("type", type);
        arr.put(o);
      }
    } finally {
      cursor.close();
    }
    return arr;
  }
}
JAVAEOF

          cat > android/app/src/main/java/com/nagham/app/MainActivity.java <<'JAVAEOF'
package com.nagham.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    registerPlugin(MediaScannerPlugin.class);
  }
}
JAVAEOF

          MANIFEST=android/app/src/main/AndroidManifest.xml
          if ! grep -q "READ_MEDIA_AUDIO" "$MANIFEST"; then
            sed -i 's#</manifest>#<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />\n    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />\n    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n</manifest>#' "$MANIFEST"
          fi
          echo "✅ تم حقن الفاحص الأصلي"

      - name: تركيب أيقونة نغم
        run: |
          ICON=""
          if [ -f public/icon-512.png ]; then ICON="public/icon-512.png"
          elif [ -f public/icons/icon-512.png ]; then ICON="public/icons/icon-512.png"
          elif [ -f icon-512.png ]; then ICON="icon-512.png"
          fi
          if [ -n "$ICON" ]; then
            sudo apt-get update -qq || true
            sudo apt-get install -y -qq imagemagick || true
            for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
              case $d in
                mdpi) s=48;; hdpi) s=72;; xhdpi) s=96;; xxhdpi) s=144;; xxxhdpi) s=192;;
              esac
              mkdir -p android/app/src/main/res/mipmap-$d
              convert "$ICON" -resize ${s}x${s} android/app/src/main/res/mipmap-$d/ic_launcher.png || true
              cp android/app/src/main/res/mipmap-$d/ic_launcher.png android/app/src/main/res/mipmap-$d/ic_launcher_round.png 2>/dev/null || true
            done
            for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
              case $d in
                mdpi) s=108;; hdpi) s=162;; xhdpi) s=216;; xxhdpi) s=324;; xxxhdpi) s=432;;
              esac
              mkdir -p android/app/src/main/res/drawable-$d
              convert "$ICON" -resize 66% -background none -gravity center -extent ${s}x${s} android/app/src/main/res/drawable-$d/ic_launcher_foreground.png || true
            done
            rm -f android/app/src/main/res/drawable-v24/ic_launcher_foreground.xml
          fi

      - name: بناء ملف APK
        working-directory: android
        run: ./gradlew assembleDebug

      - name: تسمية الملف النهائي
        run: cp android/app/build/outputs/apk/debug/app-debug.apk nagham.apk

      - name: رفع الـ APK كمرفق
        uses: actions/upload-artifact@v4
        with:
          name: nagham-apk
          path: nagham.apk

      - name: حذف الإصدار القديم
        env:
          GH_TOKEN: ${{ github.token }}
        run: gh release delete nagham-latest --yes --cleanup-tag --repo ${{ github.repository }} || true

      - name: نشر الإصدار الجديد
        uses: softprops/action-gh-release@v2
        with:
          tag_name: nagham-latest
          name: نغم — تطبيق أندرويد
          body: |
            📲 أحدث نسخة من تطبيق نغم (مبنية من الملف المضغوط)

            حمّل nagham.apk وافتحه على هاتفك لتثبيته مباشرة.
            - فحص تلقائي لكل ملفات الهاتف عند الفتح
            - معادل صوتي + مؤثرات بصرية + قوائم تشغيل + فيديو بملء الشاشة
            - إيماءات: نقرة مزدوجة للتقديم/التأخير + سحب للصوت والإضاءة
          files: nagham.apk
          draft: false
          prerelease: false
```

---

## ⚠️ حل المشاكل الشائعة

| المشكلة | الحل |
|---|---|
| **رفعت ZIP ولم يُفك** | طبيعي! أنشئ مصنع البناء (المرحلة 4) وسيفكّه هو |
| **البناء لم يبدأ** | مصنع البناء غير موجود → أنشئه من الكود أعلاه |
| البناء ❌ فشل | اضغط الخطوة الحمراء وقلّدني السطر الأخير |
| **التطبيق يطلب إذن الملفات** | اسمح — ضروري للفحص التلقائي (بدون إذن يعمل الوضع اليدوي فقط) |
| **الفحص لا يجد ملفات** | تأكد من الإذن + أن الملفات في ذاكرة الهاتف الداخلية (MediaStore لا يرى بعض بطاقات SD) |
| "التثبيت محظور" | الإعدادات ← الأمان ← مصادر غير معروفة ← اسمح |
| الـ APK لا يظهر في Releases | انتظر انتهاء البناء ✅ أولًا |
| تحديث لا يُثبَّت فوق القديم | ألغِ تثبيت القديم ثم ثبّت الجديد |

---

*نغم v2.0 — صُنع بحب 🎵*
