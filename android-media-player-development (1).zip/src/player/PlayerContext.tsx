import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Playlist, RepeatMode, Track } from "../types";
import { EQ_PRESETS } from "../types";
import {
  dbDeleteTrack,
  dbGetTracks,
  dbMetaGet,
  dbMetaSet,
  dbPutTrack,
  dbPutTracks,
} from "../lib/db";
import {
  generateVideoThumb,
  isMediaFile,
  isVideoFile,
  probeAudioDuration,
  stripExt,
  uid,
} from "../lib/utils";
import { Capacitor } from "@capacitor/core";
import { scanDeviceLibrary } from "../lib/mediaScanner";

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

interface Toast {
  id: number;
  msg: string;
}

interface PlayerValue {
  tracks: Track[];
  queue: string[];
  currentIndex: number;
  current: Track | null;
  playing: boolean;
  time: number;
  duration: number;
  volume: number;
  setVolume: (v: number) => void;
  muted: boolean;
  toggleMute: () => void;
  speed: number;
  cycleSpeed: () => void;
  repeat: RepeatMode;
  cycleRepeat: () => void;
  shuffle: boolean;
  toggleShuffle: () => void;
  seek: (t: number) => void;
  playPause: () => void;
  next: (auto?: boolean) => void;
  prev: () => void;
  playFrom: (ids: string[], id: string) => void;
  stop: () => void;
  addFiles: (files: File[]) => void;
  removeTrack: (id: string) => void;
  setTrackDuration: (id: string, d: number) => void;
  setTrackThumb: (id: string, th: string) => void;
  favs: string[];
  toggleFav: (id: string) => void;
  playlists: Playlist[];
  createPlaylist: (name: string) => void;
  deletePlaylist: (id: string) => void;
  addToPlaylist: (pid: string, tid: string) => void;
  removeFromPlaylist: (pid: string, tid: string) => void;
  history: string[];
  eq: number[];
  setEqBand: (i: number, v: number) => void;
  eqOn: boolean;
  setEqOn: (v: boolean) => void;
  applyEqPreset: (name: string) => void;
  analyser: AnalyserNode | null;
  sleepEnd: number | null;
  sleepRemaining: number;
  setSleepMin: (min: number) => void;
  toasts: Toast[];
  toast: (msg: string) => void;
  registerVideoEl: (el: HTMLVideoElement | null) => void;
  syncVideo: (t: number, d: number) => void;
  onVideoEnded: () => void;
  scanning: boolean;
  scanMessage: string;
  scanLibrary: () => Promise<void>;
  bgAudio: boolean;
  startBackgroundAudio: () => void;
  exitBackgroundAudio: () => void;
}

const Ctx = createContext<PlayerValue | null>(null);

export function usePlayer() {
  const v = useContext(Ctx);
  if (!v) throw new Error("usePlayer خارج المزود");
  return v;
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [queue, setQueue] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(() => {
    const v = parseFloat(localStorage.getItem("nagham:vol") || "1");
    return isFinite(v) ? Math.min(1, Math.max(0, v)) : 1;
  });
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [shuffle, setShuffle] = useState(false);
  const [favs, setFavs] = useState<string[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const [eq, setEq] = useState<number[]>([...EQ_PRESETS["مسطّح"]]);
  const [eqOn, setEqOn] = useState(false);
  const [sleepEnd, setSleepEnd] = useState<number | null>(null);
  const [sleepRemaining, setSleepRemaining] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [scanning, setScanning] = useState(false);
  const [scanMessage, setScanMessage] = useState("");
  const [bgAudio, setBgAudio] = useState(false);
  const scanningRef = useRef(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const videoElRef = useRef<HTMLVideoElement | null>(null);
  const audioUrlRef = useRef<string | null>(null);
  const videoUrlRef = useRef<string | null>(null);

  const ctxRef = useRef<AudioContext | null>(null);
  const filtersRef = useRef<BiquadFilterNode[]>([]);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const graphReady = useRef(false);

  const current: Track | null =
    currentIndex >= 0 && queue[currentIndex]
      ? tracks.find((t) => t.id === queue[currentIndex]) ?? null
      : null;
  const currentRef = useRef(current);
  currentRef.current = current;

  const toast = (msg: string) => {
    const id = Date.now() + Math.random();
    setToasts((p) => [...p, { id, msg }]);
    window.setTimeout(() => setToasts((p) => p.filter((t) => t.id !== id)), 2800);
  };

  /* ===== معادل صوتي (Web Audio) ===== */
  const ensureGraph = () => {
    if (graphReady.current) return;
    const el = audioRef.current;
    if (!el) return;
    try {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      const src = ctx.createMediaElementSource(el);
      const freqs = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
      const filters = freqs.map((f) => {
        const flt = ctx.createBiquadFilter();
        flt.type = "peaking";
        flt.frequency.value = f;
        flt.Q.value = 1.1;
        flt.gain.value = 0;
        return flt;
      });
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 512;
      analyser.smoothingTimeConstant = 0.82;

      src.connect(filters[0]);
      for (let i = 0; i < filters.length - 1; i++) filters[i].connect(filters[i + 1]);
      filters[filters.length - 1].connect(analyser);
      analyser.connect(ctx.destination);

      ctxRef.current = ctx;
      filtersRef.current = filters;
      analyserRef.current = analyser;
      graphReady.current = true;
      if (ctx.state === "suspended") ctx.resume().catch(() => {});
    } catch {
      graphReady.current = false;
    }
  };

  useEffect(() => {
    filtersRef.current.forEach((f, i) => {
      f.gain.setTargetAtTime(eqOn ? eq[i] ?? 0 : 0, ctxRef.current?.currentTime || 0, 0.03);
    });
  }, [eq, eqOn]);

  /* ===== تحميل البيانات المحفوظة ===== */
  useEffect(() => {
    (async () => {
      try {
        const [tr, fv, pl, hs] = await Promise.all([
          dbGetTracks(),
          dbMetaGet<string[]>("favs", []),
          dbMetaGet<Playlist[]>("playlists", []),
          dbMetaGet<string[]>("history", []),
        ]);
        setTracks(tr);
        setFavs(fv);
        setPlaylists(pl);
        setHistory(hs);
      } catch {
        /* تجاهل */
      }
    })();
  }, []);

  /* ===== حفظ تلقائي ===== */
  useEffect(() => {
    dbMetaSet("favs", favs).catch(() => {});
  }, [favs]);
  useEffect(() => {
    dbMetaSet("playlists", playlists).catch(() => {});
  }, [playlists]);
  useEffect(() => {
    dbMetaSet("history", history).catch(() => {});
  }, [history]);

  /* ===== أحداث عنصر الصوت ===== */
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onMeta = () => {
      setDuration(isFinite(a.duration) ? a.duration : 0);
      const c = currentRef.current;
      if (c && !c.duration && isFinite(a.duration)) {
        setTrackDuration(c.id, a.duration);
      }
    };
    const onEnded = () => nextRef.current(true);
    a.addEventListener("play", onPlay);
    a.addEventListener("pause", onPause);
    a.addEventListener("loadedmetadata", onMeta);
    a.addEventListener("durationchange", onMeta);
    a.addEventListener("ended", onEnded);
    return () => {
      a.removeEventListener("play", onPlay);
      a.removeEventListener("pause", onPause);
      a.removeEventListener("loadedmetadata", onMeta);
      a.removeEventListener("durationchange", onMeta);
      a.removeEventListener("ended", onEnded);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ===== مرجع next لأحداث ended ===== */
  const nextRef = useRef<(auto?: boolean) => void>(() => {});
  const next = (auto = false) => {
    const q = queue;
    if (!q.length) return;
    if (repeat === "one" && auto && current) {
      const el = current.type === "video" ? videoElRef.current : audioRef.current;
      if (el) {
        el.currentTime = 0;
        el.play().catch(() => {});
      }
      return;
    }
    let i = -1;
    if (shuffle && q.length > 1) {
      do {
        i = Math.floor(Math.random() * q.length);
      } while (i === currentIndex);
    } else if (currentIndex < q.length - 1) {
      i = currentIndex + 1;
    } else if (repeat === "all") {
      i = 0;
    } else if (auto) {
      setPlaying(false);
      return;
    }
    if (i >= 0) setCurrentIndex(i);
  };
  nextRef.current = next;

  const prev = () => {
    if (!queue.length) return;
    if (time > 3) {
      seek(0);
      return;
    }
    if (currentIndex > 0) setCurrentIndex(currentIndex - 1);
    else if (repeat === "all") setCurrentIndex(queue.length - 1);
  };

  const seek = (t: number) => {
    if (current?.type === "video") {
      const el = videoElRef.current;
      if (el) el.currentTime = t;
    } else if (audioRef.current) {
      audioRef.current.currentTime = t;
    }
    setTime(t);
  };

  const playPause = () => {
    if (!current) return;
    if (current.type === "video" && !bgAudio) {
      setPlaying((p) => !p);
      return;
    }
    const a = audioRef.current;
    if (!a) return;
    if (a.paused) {
      ensureGraph();
      a.play().catch(() => toast("تعذّر تشغيل هذا الملف"));
    } else {
      a.pause();
    }
  };

  /* ===== تغيير المقطع الحالي ===== */
  useEffect(() => {
    const a = audioRef.current;
    const c = current;
    if (!a) return;
    if (!c) {
      a.pause();
      a.removeAttribute("src");
      return;
    }
    if (c.type === "video" && !bgAudio) {
      a.pause();
      a.removeAttribute("src");
      return;
    }
    ensureGraph();
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
    if (c.uri) {
      a.src = c.uri;
    } else if (c.blob) {
      const url = URL.createObjectURL(c.blob);
      audioUrlRef.current = url;
      a.src = url;
    }
    a.playbackRate = speed;
    a.volume = muted ? 0 : volume;
    a.play().catch(() => toast("تعذّر تشغيل هذا الملف"));
    setTime(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id, bgAudio]);

  /* ===== حلقة تحديث الوقت ===== */
  useEffect(() => {
    const iv = window.setInterval(() => {
      const a = audioRef.current;
      if (a && current && (current.type === "audio" || bgAudio) && !a.paused) {
        setTime(a.currentTime);
      }
    }, 250);
    return () => window.clearInterval(iv);
  }, [current?.id, current?.type, bgAudio]);

  /* ===== السجل ===== */
  useEffect(() => {
    if (!current) return;
    setHistory((p) => [current.id, ...p.filter((x) => x !== current.id)].slice(0, 50));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current?.id]);

  /* ===== الصوت ===== */
  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = muted ? 0 : volume;
    if (videoElRef.current) videoElRef.current.volume = muted ? 0 : volume;
    localStorage.setItem("nagham:vol", String(volume));
  }, [volume, muted]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.playbackRate = speed;
    if (videoElRef.current) videoElRef.current.playbackRate = speed;
  }, [speed]);

  /* ===== مؤقّت النوم ===== */
  useEffect(() => {
    if (!sleepEnd) return;
    const iv = window.setInterval(() => {
      const remain = Math.ceil((sleepEnd - Date.now()) / 60000);
      if (remain <= 0) {
        setSleepEnd(null);
        setSleepRemaining(0);
        if (audioRef.current && !audioRef.current.paused) audioRef.current.pause();
        if (videoElRef.current && !videoElRef.current.paused) videoElRef.current.pause();
        setPlaying(false);
        toast("⏰ انتهى مؤقّت النوم — تم إيقاف التشغيل");
      } else {
        setSleepRemaining(remain);
      }
    }, 1000);
    return () => window.clearInterval(iv);
  }, [sleepEnd, toast]);

  /* ===== إضافة ملفات ===== */
  const addFiles = (files: File[]) => {
    const media = files.filter(isMediaFile);
    if (!media.length) {
      toast("لا توجد ملفات وسائط مدعومة");
      return;
    }
    const now = Date.now();
    const list: Track[] = media.map((f) => ({
      id: uid(),
      name: stripExt(f.name),
      fileName: f.name,
      type: isVideoFile(f) ? "video" : "audio",
      size: f.size,
      lastModified: f.lastModified,
      addedAt: now,
      blob: f,
    }));
    dbPutTracks(list).catch(() => toast("تعذّر حفظ الملفات محليًا"));
    setTracks((p) => [...list, ...p]);
    list.forEach((t) => {
      if (!t.blob) return;
      if (t.type === "audio") {
        probeAudioDuration(t.blob).then((d) => {
          if (d > 0) setTrackDuration(t.id, d);
        });
      } else {
        generateVideoThumb(t.blob).then((th) => {
          if (th) setTrackThumb(t.id, th);
        });
      }
    });
    toast(`✨ تمت إضافة ${list.length} ${list.length === 1 ? "ملف" : "ملفات"} إلى المكتبة`);
  };

  const playFrom = (ids: string[], id: string) => {
    if (!ids.length) return;
    setQueue(ids);
    const idx = ids.indexOf(id);
    setCurrentIndex(idx >= 0 ? idx : 0);
    setPlaying(true);
    if (idx < 0) return;
    const t = tracks.find((x) => x.id === id);
    if (t && t.type === "audio") ensureGraph();
  };

  const stop = () => {
    if (audioRef.current) audioRef.current.pause();
    if (videoElRef.current) videoElRef.current.pause();
    setPlaying(false);
    setBgAudio(false);
    setCurrentIndex(-1);
  };

  const removeTrack = (id: string) => {
    const t = tracks.find((x) => x.id === id);
    if (t?.blob) dbDeleteTrack(id).catch(() => {});
    const wasCurrent = current?.id === id;
    setTracks((p) => p.filter((t) => t.id !== id));
    setFavs((p) => p.filter((x) => x !== id));
    setHistory((p) => p.filter((x) => x !== id));
    setPlaylists((p) => p.map((pl) => ({ ...pl, trackIds: pl.trackIds.filter((x) => x !== id) })));
    setQueue((p) => p.filter((x) => x !== id));
    if (wasCurrent) {
      if (audioUrlRef.current) URL.revokeObjectURL(audioUrlRef.current);
      if (videoUrlRef.current) URL.revokeObjectURL(videoUrlRef.current);
      setCurrentIndex(-1);
      setPlaying(false);
      setBgAudio(false);
    }
    toast("تم حذف الملف من المكتبة");
  };

  const setTrackDuration = (id: string, d: number) => {
    setTracks((p) =>
      p.map((t) => {
        if (t.id !== id || t.duration) return t;
        const nt = { ...t, duration: d };
        if (nt.blob) dbPutTrack(nt).catch(() => {});
        return nt;
      })
    );
  };

  const setTrackThumb = (id: string, th: string) => {
    setTracks((p) =>
      p.map((t) => {
        if (t.id !== id || t.thumbnail) return t;
        const nt = { ...t, thumbnail: th };
        dbPutTrack(nt).catch(() => {});
        return nt;
      })
    );
  };

  const toggleFav = (id: string) => {
    setFavs((p) => {
      const has = p.includes(id);
      toast(has ? "تمت الإزالة من المفضلة" : "❤️ أُضيف إلى المفضلة");
      return has ? p.filter((x) => x !== id) : [id, ...p];
    });
  };

  const createPlaylist = (name: string) => {
    const n = name.trim();
    if (!n) return;
    setPlaylists((p) => [
      ...p,
      { id: uid(), name: n, trackIds: [], createdAt: Date.now() },
    ]);
    toast("📁 تم إنشاء القائمة");
  };

  const deletePlaylist = (id: string) => {
    setPlaylists((p) => p.filter((pl) => pl.id !== id));
    toast("تم حذف القائمة");
  };

  const addToPlaylist = (pid: string, tid: string) => {
    setPlaylists((p) =>
      p.map((pl) =>
        pl.id === pid && !pl.trackIds.includes(tid)
          ? { ...pl, trackIds: [...pl.trackIds, tid] }
          : pl
      )
    );
    toast("🎵 أُضيفت إلى القائمة");
  };

  const removeFromPlaylist = (pid: string, tid: string) => {
    setPlaylists((p) =>
      p.map((pl) => (pl.id === pid ? { ...pl, trackIds: pl.trackIds.filter((x) => x !== tid) } : pl))
    );
  };

  const setVolume = (v: number) => setVolumeState(Math.min(1, Math.max(0, v)));
  const toggleMute = () => setMuted((m) => !m);
  const cycleSpeed = () =>
    setSpeed((s) => SPEEDS[(SPEEDS.indexOf(s) + 1) % SPEEDS.length]);
  const cycleRepeat = () =>
    setRepeat((r) => (r === "off" ? "all" : r === "all" ? "one" : "off"));
  const toggleShuffle = () => setShuffle((s) => !s);
  const setEqBand = (i: number, v: number) =>
    setEq((p) => p.map((x, j) => (j === i ? v : x)));
  const applyEqPreset = (name: string) => {
    setEq([...EQ_PRESETS[name]]);
    setEqOn(true);
  };
  const setSleepMin = (min: number) => {
    if (min <= 0) {
      setSleepEnd(null);
      setSleepRemaining(0);
      toast("تم إلغاء مؤقّت النوم");
    } else {
      setSleepEnd(Date.now() + min * 60000);
      setSleepRemaining(min);
      toast(`⏰ سيتم الإيقاف بعد ${min} دقيقة`);
    }
  };
  const registerVideoEl = (el: HTMLVideoElement | null) => {
    videoElRef.current = el;
  };
  const syncVideo = (t: number, d: number) => {
    setTime(t);
    setDuration(d);
  };
  const onVideoEnded = () => next(true);

  /* ===== الفحص التلقائي لملفات الجهاز (أندرويد) ===== */
  const scanLibrary = async () => {
    if (!Capacitor.isNativePlatform()) return;
    if (scanningRef.current) return;
    scanningRef.current = true;
    setScanning(true);
    setScanMessage("بدء الفحص...");
    const found = await scanDeviceLibrary(setScanMessage);
    if (found.length) {
      setTracks((prev) => {
        const manual = prev.filter((t) => t.blob);
        const uris = new Set(manual.map((t) => t.uri).filter(Boolean) as string[]);
        const merged = [...found.filter((t) => !uris.has(t.uri || "")), ...manual];
        return merged;
      });
      toast(`📡 تم العثور على ${found.length} ملف وسائط في جهازك`);
    } else {
      toast("لم يُعثر على ملفات — أضفها يدويًا من زر فتح الملفات");
    }
    setScanning(false);
    setScanMessage("");
    scanningRef.current = false;
  };

  /* ===== التشغيل في الخلفية 🎧 ===== */
  const startBackgroundAudio = () => {
    if (!current) return;
    if (current.type === "audio") {
      toast("🎧 التشغيل مستمر في الخلفية — يمكنك الخروج من التطبيق");
      return;
    }
    setBgAudio(true);
    setPlaying(true);
    toast("🎧 يعمل الآن في الخلفية — أغلق الشاشة أو تصفح هاتفك");
  };

  const exitBackgroundAudio = () => {
    if (!bgAudio) return;
    const a = audioRef.current;
    const v = videoElRef.current;
    if (a && v && current?.type === "video") {
      v.currentTime = a.currentTime;
      v.volume = muted ? 0 : volume;
    }
    setBgAudio(false);
    setPlaying(true);
  };

  const value: PlayerValue = {
    tracks,
    queue,
    currentIndex,
    current,
    playing,
    time,
    duration,
    volume,
    setVolume,
    muted,
    toggleMute,
    speed,
    cycleSpeed,
    repeat,
    cycleRepeat,
    shuffle,
    toggleShuffle,
    seek,
    playPause,
    next,
    prev,
    playFrom,
    stop,
    addFiles,
    removeTrack,
    setTrackDuration,
    setTrackThumb,
    favs,
    toggleFav,
    playlists,
    createPlaylist,
    deletePlaylist,
    addToPlaylist,
    removeFromPlaylist,
    history,
    eq,
    setEqBand,
    eqOn,
    setEqOn,
    applyEqPreset,
    analyser: analyserRef.current,
    sleepEnd,
    sleepRemaining,
    setSleepMin,
    toasts,
    toast,
    registerVideoEl,
    syncVideo,
    onVideoEnded,
    scanning,
    scanMessage,
    scanLibrary,
    bgAudio,
    startBackgroundAudio,
    exitBackgroundAudio,
  };

  return (
    <Ctx.Provider value={value}>
      <audio ref={audioRef} preload="auto" />
      {children}
    </Ctx.Provider>
  );
}
