export interface Track {
  id: string;
  name: string; // بدون الامتداد
  fileName: string;
  type: "audio" | "video";
  size: number;
  lastModified: number;
  addedAt: number;
  blob: Blob | null; // ملف مرفوع يدويًا
  uri?: string; // مسار content:// من فحص الجهاز
  album?: string;
  artist?: string;
  duration?: number;
  thumbnail?: string; // صورة مصغرة للفيديو (dataURL)
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
}

export type RepeatMode = "off" | "all" | "one";

export const EQ_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const EQ_PRESETS: Record<string, number[]> = {
  "مسطّح": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "بوب": [-1, 1, 3, 4, 2, 0, -1, 1, 2, 2],
  "روك": [4, 3, 2, -1, -2, -1, 1, 3, 4, 4],
  "جاز": [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
  "باس قوي": [6, 5, 4, 2, 0, -1, -2, -1, 0, 1],
  "كلاسيكي": [2, 1, 0, -1, -1, 0, 2, 3, 3, 2],
  "صوتي": [3, 2, 1, 0, -1, 0, 1, 2, 3, 3],
  "إلكتروني": [3, 2, 0, -1, 0, 2, 3, 2, 1, 3],
};
