import { useEffect, useRef, type RefObject } from "react";

type Side = "left" | "right";

interface Handlers {
  onTap?: (side: Side) => void;
  onDoubleTap?: (side: Side) => void;
  onVertical?: (side: Side, delta: number) => void;
  onHorizontal?: (delta: number) => void;
  onAny?: () => void;
}

/* ===== لوحة الإيماءات الاحترافية =====
   - نقرة مزدوجة على اليمين/اليسار → تقديم/تأخير
   - سحب عمودي على اليمين → الصوت
   - سحب عمودي على اليسار → الإضاءة
   - سحب أفقي → تقديم/تأخير سريع
*/
export function useGesturePad(
  ref: RefObject<HTMLElement | null>,
  handlers: Handlers
) {
  const st = useRef({
    x: 0,
    y: 0,
    t: 0,
    mode: "" as "" | "v" | "h",
    active: false,
    lastTap: 0,
  });
  const h = useRef(handlers);
  h.current = handlers;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const side = (clientX: number) => {
      const r = el.getBoundingClientRect();
      return clientX < r.width / 2 ? ("left" as Side) : ("right" as Side);
    };

    const down = (e: PointerEvent) => {
      st.current = {
        x: e.clientX,
        y: e.clientY,
        t: Date.now(),
        mode: "",
        active: true,
        lastTap: st.current.lastTap,
      };
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* تجاهل */
      }
      h.current.onAny?.();
    };

    const move = (e: PointerEvent) => {
      const s = st.current;
      if (!s.active) return;
      h.current.onAny?.();
      const dx = e.clientX - s.x;
      const dy = e.clientY - s.y;
      if (!s.mode) {
        if (Math.abs(dy) > 16 && Math.abs(dy) > Math.abs(dx) * 1.25) s.mode = "v";
        else if (Math.abs(dx) > 22 && Math.abs(dx) > Math.abs(dy) * 1.25) s.mode = "h";
        if (s.mode) {
          s.x = e.clientX;
          s.y = e.clientY;
        }
        return;
      }
      if (s.mode === "v") {
        const delta = (s.y - e.clientY) / 350;
        s.y = e.clientY;
        h.current.onVertical?.(side(e.clientX), delta);
      } else {
        const delta = (e.clientX - s.x) / 50;
        s.x = e.clientX;
        h.current.onHorizontal?.(delta);
      }
    };

    const up = (e: PointerEvent) => {
      const s = st.current;
      if (!s.active) return;
      s.active = false;
      const dt = Date.now() - s.t;
      if (s.mode === "" && dt < 350) {
        const now = Date.now();
        if (now - s.lastTap < 300) {
          s.lastTap = 0;
          h.current.onDoubleTap?.(side(e.clientX));
        } else {
          s.lastTap = now;
          h.current.onTap?.(side(e.clientX));
        }
      }
    };

    el.addEventListener("pointerdown", down);
    el.addEventListener("pointermove", move);
    el.addEventListener("pointerup", up);
    el.addEventListener("pointercancel", up);
    return () => {
      el.removeEventListener("pointerdown", down);
      el.removeEventListener("pointermove", move);
      el.removeEventListener("pointerup", up);
      el.removeEventListener("pointercancel", up);
    };
  }, [ref]);
}
