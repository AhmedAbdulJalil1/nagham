import {
  Film,
  FolderOpen,
  Heart,
  History,
  Home,
  ListMusic,
  Music2,
  Waves,
} from "lucide-react";
import type { Track } from "../types";
import { formatBytes, formatTime } from "../lib/utils";

export type TabId = "all" | "music" | "video" | "favs" | "playlists" | "history";

interface Props {
  tab: TabId;
  onTab: (t: TabId) => void;
  tracks: Track[];
  favsCount: number;
  playlistsCount: number;
  openFiles: () => void;
}

const NAV: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: "all", label: "المكتبة", icon: Home },
  { id: "music", label: "الموسيقى", icon: Music2 },
  { id: "video", label: "الفيديو", icon: Film },
  { id: "favs", label: "المفضلة", icon: Heart },
  { id: "playlists", label: "قوائم التشغيل", icon: ListMusic },
  { id: "history", label: "سجل الاستماع", icon: History },
];

export default function Sidebar({ tab, onTab, tracks, favsCount, playlistsCount, openFiles }: Props) {
  const music = tracks.filter((t) => t.type === "audio").length;
  const video = tracks.filter((t) => t.type === "video").length;
  const totalSize = tracks.reduce((s, t) => s + t.size, 0);
  const totalTime = tracks.reduce((s, t) => s + (t.duration || 0), 0);

  const countFor = (id: TabId) =>
    id === "music" ? music : id === "video" ? video : id === "favs" ? favsCount : id === "playlists" ? playlistsCount : tracks.length;

  return (
    <aside className="hidden md:flex w-64 shrink-0 flex-col border-l border-white/5 bg-white/[0.02]">
      {/* الشعار */}
      <div className="flex items-center gap-3 px-5 pt-6 pb-5">
        <div className="relative h-11 w-11 rounded-2xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-amber-400 grid place-items-center shadow-lg shadow-fuchsia-500/30">
          <Waves className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-black leading-tight">
            نغم
            <span className="text-fuchsia-400">.</span>
          </h1>
          <p className="text-[11px] text-white/40 font-semibold">مشغّل الموسيقى والفيديو</p>
        </div>
      </div>

      {/* زر فتح الملفات */}
      <div className="px-4 pb-4">
        <button
          onClick={openFiles}
          className="w-full flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-violet-600 to-fuchsia-600 py-3 text-sm font-bold shadow-lg shadow-violet-600/30 hover:brightness-110 active:scale-[0.98] transition"
        >
          <FolderOpen className="h-4 w-4" />
          فتح ملفات الوسائط
        </button>
        <p className="mt-2 text-center text-[10px] text-white/35">MP3 · MP4 · FLAC · WEBM والمزيد</p>
      </div>

      {/* التنقل */}
      <nav className="flex-1 space-y-1 px-3 overflow-y-auto no-scrollbar">
        {NAV.map(({ id, label, icon: Icon }) => {
          const active = tab === id;
          return (
            <button
              key={id}
              onClick={() => onTab(id)}
              className={`w-full flex items-center justify-between rounded-xl px-3 py-2.5 text-sm font-bold transition ${
                active
                  ? "bg-gradient-to-l from-violet-600/25 to-fuchsia-600/15 text-white ring-1 ring-violet-500/30"
                  : "text-white/55 hover:bg-white/5 hover:text-white"
              }`}
            >
              <span className="flex items-center gap-3">
                <Icon className={`h-4.5 w-4.5 ${active ? "text-fuchsia-400" : ""}`} />
                {label}
              </span>
              {id !== "all" && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-md ${
                    active ? "bg-fuchsia-500/25 text-fuchsia-200" : "bg-white/5 text-white/40"
                  }`}
                >
                  {countFor(id)}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* الإحصائيات */}
      <div className="mx-4 mb-4 rounded-2xl glass p-4 space-y-2 text-[11px]">
        <div className="flex justify-between text-white/60">
          <span>الملفات</span>
          <span className="font-bold text-white">{tracks.length}</span>
        </div>
        <div className="flex justify-between text-white/60">
          <span>المساحة</span>
          <span className="font-bold text-white">{formatBytes(totalSize)}</span>
        </div>
        <div className="flex justify-between text-white/60">
          <span>الوقت الكلي</span>
          <span className="font-bold text-white">{formatTime(totalTime)}</span>
        </div>
        <div className="pt-1 border-t border-white/5 flex justify-between text-white/60">
          <span>موسيقى / فيديو</span>
          <span className="font-bold text-white">
            {music} / {video}
          </span>
        </div>
      </div>

      <div className="px-5 pb-4 text-center text-[10px] text-white/25">
        نغم v1.0 — يعمل بدون إنترنت تمامًا
      </div>
    </aside>
  );
}
