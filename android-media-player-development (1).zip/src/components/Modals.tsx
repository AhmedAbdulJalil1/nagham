import { useState } from "react";
import {
  Check,
  Clock,
  ListPlus,
  Plus,
  Trash2,
  X,
} from "lucide-react";
import { usePlayer } from "../player/PlayerContext";
import { EQ_BANDS, EQ_PRESETS } from "../types";
import RangeSlider from "./RangeSlider";

/* ===== غلاف النافذة ===== */
function Sheet({
  title,
  onClose,
  children,
  wide = false,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center anim-fade">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div
        className={`relative w-full ${wide ? "sm:max-w-lg" : "sm:max-w-md"} bg-[#12121c] border border-white/10 rounded-t-3xl sm:rounded-3xl shadow-2xl anim-scale-in max-h-[88vh] overflow-y-auto`}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 bg-[#12121c]/95 backdrop-blur border-b border-white/5">
          <h3 className="text-base font-black">{title}</h3>
          <button
            onClick={onClose}
            className="grid place-items-center h-9 w-9 rounded-full bg-white/5 text-white/60 hover:bg-white/10 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

/* ===== المعادل الصوتي ===== */
export function EqualizerModal({ onClose }: { onClose: () => void }) {
  const p = usePlayer();
  return (
    <Sheet title="المعادل الصوتي" onClose={onClose} wide>
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm font-bold text-white/70">تفعيل المعادل</span>
        <button
          onClick={() => p.setEqOn(!p.eqOn)}
          className={`relative h-7 w-14 rounded-full transition ${
            p.eqOn ? "bg-gradient-to-l from-violet-500 to-fuchsia-500" : "bg-white/10"
          }`}
        >
          <span
            className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${
              p.eqOn ? "left-1" : "left-8"
            }`}
          />
        </button>
      </div>

      {/* الإعدادات المسبقة */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1 mb-5">
        {Object.keys(EQ_PRESETS).map((name) => (
          <button
            key={name}
            onClick={() => p.applyEqPreset(name)}
            className={`shrink-0 rounded-full px-4 py-1.5 text-xs font-bold transition ${
              JSON.stringify(p.eq) === JSON.stringify(EQ_PRESETS[name]) && p.eqOn
                ? "bg-fuchsia-500/25 text-fuchsia-200 ring-1 ring-fuchsia-400/40"
                : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            {name}
          </button>
        ))}
      </div>

      {/* النطاقات */}
      <div className="grid grid-cols-5 gap-x-3 gap-y-5">
        {EQ_BANDS.map((freq, i) => {
          const v = p.eq[i] ?? 0;
          const active = p.eqOn && v !== 0;
          return (
            <div key={freq} className="flex flex-col items-center gap-1.5">
              <span
                className={`text-[9px] font-black tabular-nums ${
                  active ? "text-fuchsia-300" : "text-white/30"
                }`}
                dir="ltr"
              >
                {v > 0 ? `+${v}` : v}
              </span>
              <RangeSlider
                className="h-20"
                small
                value={v}
                min={-12}
                max={12}
                step={1}
                onChange={(nv) => p.setEqBand(i, nv)}
              />
              <span className="text-[9px] text-white/35 tabular-nums" dir="ltr">
                {freq >= 1000 ? `${freq / 1000}k` : freq}
              </span>
            </div>
          );
        })}
      </div>
      <p className="mt-4 text-[11px] text-white/35 text-center">
        يعمل المعادل على جميع الأغاني عبر Web Audio API بجودة عالية
      </p>
    </Sheet>
  );
}

/* ===== مؤقت النوم ===== */
export function SleepTimerModal({ onClose }: { onClose: () => void }) {
  const p = usePlayer();
  const options = [15, 30, 45, 60, 90];
  return (
    <Sheet title="مؤقّت النوم" onClose={onClose}>
      <p className="text-sm text-white/50 mb-4">
        سيتم إيقاف التشغيل تلقائيًا بعد الوقت المحدد — مثالي للنوم على الموسيقى 🌙
      </p>
      <div className="grid grid-cols-3 gap-3">
        {options.map((m) => (
          <button
            key={m}
            onClick={() => p.setSleepMin(m)}
            className={`flex flex-col items-center gap-1 rounded-2xl py-4 border transition ${
              p.sleepEnd && p.sleepRemaining <= m
                ? "border-amber-400/50 bg-amber-500/10 text-amber-300"
                : "border-white/8 bg-white/5 text-white/70 hover:bg-white/10"
            }`}
          >
            <Clock className="h-5 w-5" />
            <span className="text-lg font-black tabular-nums">{m}</span>
            <span className="text-[10px] text-white/40">دقيقة</span>
          </button>
        ))}
        <button
          onClick={() => p.setSleepMin(0)}
          className="flex flex-col items-center justify-center gap-1 rounded-2xl py-4 border border-white/8 bg-white/5 text-white/70 hover:bg-white/10"
        >
          <X className="h-5 w-5" />
          <span className="text-sm font-bold">إلغاء</span>
        </button>
      </div>
      {p.sleepEnd && (
        <div className="mt-4 rounded-xl bg-amber-500/10 border border-amber-400/20 px-4 py-3 text-center text-sm font-bold text-amber-300">
          ⏰ سيتوقف التشغيل بعد {p.sleepRemaining} دقيقة
        </div>
      )}
    </Sheet>
  );
}

/* ===== قوائم التشغيل ===== */
export function PlaylistModal({
  onClose,
  trackId,
}: {
  onClose: () => void;
  trackId: string | null; // null = وضع الإدارة
}) {
  const p = usePlayer();
  const [name, setName] = useState("");

  const addToPlaylist = (pid: string) => {
    p.addToPlaylist(pid, trackId!);
    if (trackId) onClose();
  };

  return (
    <Sheet title={trackId ? "أضف إلى قائمة تشغيل" : "قوائم التشغيل"} onClose={onClose}>
      {/* إنشاء قائمة */}
      <div className="flex gap-2 mb-5">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && name.trim()) {
              p.createPlaylist(name);
              setName("");
            }
          }}
          placeholder="اسم القائمة الجديدة..."
          className="flex-1 rounded-xl bg-white/5 border border-white/10 px-4 py-2.5 text-sm outline-none focus:border-fuchsia-400/50 placeholder:text-white/25"
        />
        <button
          onClick={() => {
            if (name.trim()) {
              p.createPlaylist(name);
              setName("");
            }
          }}
          className="grid place-items-center h-11 w-11 shrink-0 rounded-xl bg-gradient-to-l from-violet-600 to-fuchsia-600 shadow-lg shadow-fuchsia-600/25"
        >
          <Plus className="h-5 w-5" />
        </button>
      </div>

      <div className="space-y-2">
        {p.playlists.length === 0 && (
          <p className="text-center text-sm text-white/35 py-6">
            لا توجد قوائم بعد — أنشئ أول قائمة 👆
          </p>
        )}
        {p.playlists.map((pl) => {
          const contains = trackId ? pl.trackIds.includes(trackId) : false;
          return (
            <div
              key={pl.id}
              className="flex items-center gap-3 rounded-xl bg-white/5 px-4 py-3"
            >
              <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-violet-500/30 to-fuchsia-500/30 grid place-items-center">
                <ListPlus className="h-4 w-4 text-fuchsia-300" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold truncate">{pl.name}</p>
                <p className="text-[10px] text-white/40">{pl.trackIds.length} مقطع</p>
              </div>
              {trackId ? (
                <button
                  onClick={() => addToPlaylist(pl.id)}
                  disabled={contains}
                  className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-[11px] font-bold transition ${
                    contains
                      ? "bg-emerald-500/15 text-emerald-300"
                      : "bg-fuchsia-500/20 text-fuchsia-200 hover:bg-fuchsia-500/30"
                  }`}
                >
                  <Check className="h-3.5 w-3.5" />
                  {contains ? "مضافة" : "إضافة"}
                </button>
              ) : (
                <button
                  onClick={() => p.deletePlaylist(pl.id)}
                  className="grid place-items-center h-8 w-8 rounded-lg text-white/40 hover:text-rose-400 hover:bg-rose-500/10"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </Sheet>
  );
}
