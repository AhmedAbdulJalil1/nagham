import type { CSSProperties } from "react";

interface Props {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange: (v: number) => void;
  className?: string;
  small?: boolean;
  disabled?: boolean;
}

export default function RangeSlider({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  className = "",
  small = false,
  disabled = false,
}: Props) {
  const pct = max === min ? 0 : ((value - min) / (max - min)) * 100;
  return (
    <input
      type="range"
      className={`slider ${small ? "sm" : ""} ${className}`}
      style={{ "--p": `${pct}%` } as CSSProperties}
      min={min}
      max={max}
      step={step}
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(parseFloat(e.target.value))}
    />
  );
}
