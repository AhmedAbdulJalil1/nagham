import { useEffect, useRef, useState } from "react";
import {
  Headphones,
  Maximize,
  Minimize,
  Pause,
  Play,
  RotateCw,
  SkipBack,
  SkipForward,
  X,
} from "lucide-react";
import { Capacitor } from "@capacitor/core";
import { StatusBar } from "@capacitor/status-bar";
import { ScreenOrientation } from "@capacitor/screen-orientation";
import { usePlayer } from "../player/PlayerContext";
import { formatTime } from "../lib/utils";
import RangeSlider from "./RangeSlider";
import { useGesturePad } from "../hooks/useGestures";

export default function VideoPlayer() {
  const p = usePlayer();
  const c = p.current;
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const urlRef = useRef<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [rotated, setRotated] = useState(false);
  const [bright, setBright] = useState(1);
  const [hud, setHud] = useState<string | null>(null);
  const hideTimer = useRef(0);
  const hudTimer = useRef(0);
  const brightRef = useRef(1);
  const volRef = useRef(p.volume);
  const pRef = useRef(p);
  pRef.current = p;

  const isVideo = !!c && c.type === "video";

  /* إخفاء شريط الإشعارات أثناء الفيديو */
  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      StatusBar.hide().catch(() => {});
      StatusBar.setOverlaysWebView({ overlay: true }).catch(() => {});
    }
    return () => {
      if (Capacitor.isNativePlatform()) StatusBar.show().catch(() => {});
    };
  }, []);

  /* إعادة الشاشة للوضع العمودي عند الإغلاق */
  useEffect(() => {
    return () => {
      if (Capacitor.isNativePlatform()) {
        ScreenOrientation.lock({ orientation: "portrait" }).catch(() => {});
      }
    };
  }, []);

  const showHud = (msg: string) => {
    setHud(msg);
    window.clearTimeout(hudTimer.current);
    hudTimer.current = window.setTimeout(() => setHud(null), 800);
  };

  const seekTo = (t: number) => {
    const d = pRef.current.duration || 0;
    pRef.current.seek(Math.min(d, Math.max(0, t)));
  };

  const showControls = () => {
    setControlsVisible(true);
    window.clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => setControlsVisible(false), 2800);
  };

  /* ===== لوحة الإيماءات الاحترافية ===== */
  useGesturePad(containerRef, {
    onAny: () => showControls(),
    onTap: () => setControlsVisible((s) => !s),
    onDoubleTap: (side) => {
      const d = side === "right" ? 10 : -10;
      seekTo(pRef.current.time + d);
      showHud(d > 0 ? "⏩ +10 ث" : "⏪ -10 ث");
    },
    onVertical: (side, delta) => {
      if (side === "right") {
        const nv = Math.min(1, Math.max(0, volRef.current + delta));
        volRef.current = nv;
        pRef.current.setVolume(nv);
        const v = videoRef.current;
        if (v) v.volume = nv;
        showHud(`🔊 ${Math.round(nv * 100)}%`);
      } else {
        const nb = Math.min(1, Math.max(0.15, brightRef.current + delta));
        brightRef.current = nb;
        setBright(nb);
        showHud(`☀️ ${Math.round(nb * 100)}%`);
      }
    },
    onHorizontal: (delta) => {
      seekTo(pRef.current.time + delta);
      showHud(`${delta >= 0 ? "⏩ +" : "⏪ "}${Math.abs(delta).toFixed(0)}ث`);
    },
  });

  /* تسجيل عنصر الفيديو في المحرك */
  useEffect(() => {
    p.registerVideoEl(isVideo ? videoRef.current : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isVideo]);

  /* تحميل المصدر عند تغيّر المقطع */
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !c || c.type !== "video") return;
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    }
    if (c.uri) v.src = c.uri;
    else if (c.blob) {
      const url = URL.createObjectURL(c.blob);
      urlRef.current = url;
      v.src = url;
    }
    v.playbackRate = p.speed;
    v.volume = p.muted ? 0 : p.volume;
    if (p.playing) v.play().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [c?.id]);

  /* مزامنة التشغيل/الإيقاف */
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !c || c.type !== "video") return;
    if (p.playing) v.play().catch(() => {});
    else v.pause();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.playing]);

  /* تنظيف عند الإغلاق */
  useEffect(() => {
    return () => {
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      p.registerVideoEl(null);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!isVideo || !c) return null;

  const toggleFullscreen = () => {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else containerRef.current?.requestFullscreen().catch(() => {});
  };

  const toggleRotate = () => {
    if (Capacitor.isNativePlatform()) {
      ScreenOrientation.lock({
        orientation: rotated ? "portrait" : "landscape",
      }).catch(() => {});
    } else {
      toggleFullscreen();
    }
    setRotated((r) => !r);
  };

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const close = () => p.stop();
  const fade = controlsVisible ? "opacity-100" : "opacity-0 pointer-events-none";

  return (
    <div
      ref={containerRef}
      dir="ltr"
      className="fixed inset-0 z-[65] bg-black anim-fade flex flex-col touch-none select-none"
    >
      {/* الشريط العلوي */}
      <div
        className={`absolute top-0 inset-x-0 z-10 flex items-center justify-between px-4 pt-4 pb-10 bg-gradient-to-b from-black/80 to-transparent transition-opacity duration-300 ${fade}`}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shrink-0" />
          <span className="truncate text-sm font-bold text-white">{c.name}</span>
        </div>
        <button
          onClick={close}
          className="grid place-items-center h-10 w-10 rounded-full bg-white/10 text-white hover:bg-white/20 shrink-0"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* الفيديو */}
      <video
        ref={videoRef}
        className="w-full h-full object-contain relative z-[1]"
        playsInline
        onTimeUpdate={(e) =>
          p.syncVideo(e.currentTarget.currentTime, e.currentTarget.duration || 0)
        }
        onLoadedMetadata={(e) => p.syncVideo(0, e.currentTarget.duration || 0)}
        onEnded={p.onVideoEnded}
      />

      {/* طبقة الإضاءة */}
      <div
        className="absolute inset-0 z-[5] bg-black pointer-events-none transition-opacity duration-150"
        style={{ opacity: 1 - bright }}
      />

      {/* مؤشر الإيماءات */}
      <div className="absolute inset-0 z-20 grid place-items-center pointer-events-none">
        {hud && (
          <div
            key={hud}
            className="anim-scale-in rounded-2xl bg-black/70 backdrop-blur-md px-6 py-3.5 text-xl font-black text-white shadow-2xl"
          >
            {hud}
          </div>
        )}
      </div>

      {/* زر السابق — الجانب الأيسر */}
      <div
        className={`absolute left-2 top-1/2 -translate-y-1/2 z-20 transition-opacity duration-300 ${fade}`}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <button
          onClick={p.prev}
          className="grid place-items-center h-12 w-12 rounded-2xl bg-black/50 backdrop-blur text-white/90 border border-white/10 hover:bg-fuchsia-600/60"
          title="المقطع السابق"
        >
          <SkipBack className="h-5 w-5 fill-current" />
        </button>
      </div>

      {/* زر التالي — الجانب الأيمن */}
      <div
        className={`absolute right-2 top-1/2 -translate-y-1/2 z-20 transition-opacity duration-300 ${fade}`}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => p.next()}
          className="grid place-items-center h-12 w-12 rounded-2xl bg-black/50 backdrop-blur text-white/90 border border-white/10 hover:bg-fuchsia-600/60"
          title="المقطع التالي"
        >
          <SkipForward className="h-5 w-5 fill-current" />
        </button>
      </div>

      {/* شريط التحكم السفلي */}
      <div
        className={`absolute bottom-0 inset-x-0 z-10 px-4 pb-5 pt-12 bg-gradient-to-t from-black/85 to-transparent transition-opacity duration-300 ${fade}`}
        onPointerDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3">
          <span className="text-[11px] tabular-nums text-white/70 w-11" dir="ltr">
            {formatTime(p.time)}
          </span>
          <RangeSlider
            className="flex-1"
            small
            value={p.time}
            max={p.duration || 1}
            step={0.1}
            onChange={p.seek}
          />
          <span className="text-[11px] tabular-nums text-white/70 w-11" dir="ltr">
            {formatTime(p.duration)}
          </span>
        </div>
        <div className="mt-2 flex items-center gap-1.5">
          <button
            onClick={p.playPause}
            className="grid place-items-center h-11 w-11 rounded-full bg-white text-black shrink-0"
          >
            {p.playing ? (
              <Pause className="h-5 w-5 fill-current" />
            ) : (
              <Play className="h-5 w-5 fill-current pr-0.5" />
            )}
          </button>
          <button
            onClick={() => p.next()}
            className="grid place-items-center h-10 w-10 rounded-full text-white/80 hover:bg-white/10 shrink-0"
          >
            <SkipForward className="h-5 w-5 fill-current" />
          </button>
          <span className="text-[11px] font-bold text-white/60 mx-1 truncate flex-1">
            {c.name}
          </span>
          <button
            onClick={p.cycleSpeed}
            className="text-[11px] font-black text-white/70 px-2.5 py-1.5 rounded-lg hover:bg-white/10 tabular-nums shrink-0"
          >
            {p.speed}×
          </button>
          <button
            onClick={p.startBackgroundAudio}
            className="grid place-items-center h-10 w-10 rounded-full text-white/80 hover:bg-white/10 shrink-0"
            title="تشغيل الصوت في الخلفية"
          >
            <Headphones className="h-5 w-5" />
          </button>
          <button
            onClick={toggleRotate}
            className={`grid place-items-center h-10 w-10 rounded-full shrink-0 ${
              rotated ? "text-fuchsia-300 bg-fuchsia-500/20" : "text-white/80 hover:bg-white/10"
            }`}
            title="تدوير الشاشة"
          >
            <RotateCw className="h-5 w-5" />
          </button>
          <button
            onClick={toggleFullscreen}
            className="grid place-items-center h-10 w-10 rounded-full text-white/80 hover:bg-white/10 shrink-0"
            title="ملء الشاشة"
          >
            {fullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
          </button>
        </div>
      </div>
    </div>
  );
}
