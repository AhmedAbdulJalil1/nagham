import { useEffect, useRef } from "react";

interface Props {
  analyser: AnalyserNode | null;
  active: boolean;
  bars?: number;
  className?: string;
}

/* لوحة رسم المؤثرات الصوتية — أعمدة حية من محلل الترددات */
export default function VisualizerCanvas({ analyser, active, bars = 56, className = "" }: Props) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    const data = new Uint8Array(analyser ? analyser.frequencyBinCount : 0);

    const draw = (t: number) => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const n = bars;
      const bw = w / n;
      const grad = ctx.createLinearGradient(0, h, 0, 0);
      grad.addColorStop(0, "#a855f7");
      grad.addColorStop(0.5, "#d946ef");
      grad.addColorStop(1, "#f59e0b");
      ctx.fillStyle = grad;

      let sum = 0;
      if (analyser && active) {
        analyser.getByteFrequencyData(data);
        for (let i = 0; i < data.length; i++) sum += data[i];
      }

      for (let i = 0; i < n; i++) {
        let v: number;
        if (analyser && active && data.length) {
          const idx = Math.floor(Math.pow(i / n, 1.6) * data.length * 0.7);
          v = data[idx] / 255;
        } else {
          v = 0.06 + 0.05 * Math.sin(t / 400 + i * 0.55) + 0.03 * Math.sin(t / 250 + i * 0.9);
        }
        const bh = Math.max(2, v * h * 0.92);
        const x = i * bw + bw * 0.18;
        const ww = bw * 0.64;
        const r = ww / 2;
        ctx.beginPath();
        ctx.roundRect(x, h - bh, ww, bh, r);
        ctx.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [analyser, active, bars]);

  return (
    <canvas
      ref={ref}
      className={className}
      style={{ width: "100%" }}
      height={96}
      aria-hidden
    />
  );
}
