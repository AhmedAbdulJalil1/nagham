import { Capacitor, registerPlugin } from "@capacitor/core";
import type { Track } from "../types";
import { stripExt } from "./utils";

/* ===== الفاحص الأصلي (MediaStore) — يحقنه مصنع البناء في مشروع أندرويد =====
   يستعلم قاعدة بيانات وسائط النظام مباشرة: سريع جدًا حتى مع آلاف الملفات */
interface NativeScanner {
  requestPermissions(): Promise<{ granted: boolean }>;
  scan(): Promise<{ media: NativeMedia[] }>;
}
interface NativeMedia {
  id: string;
  name: string;
  size: number;
  dateModified: number;
  duration: number;
  album?: string;
  artist?: string;
  uri: string;
  type: "audio" | "video";
}

const NativeScanner = registerPlugin<NativeScanner>("MediaScanner");

export async function scanDeviceLibrary(
  onProgress: (msg: string) => void
): Promise<Track[]> {
  if (!Capacitor.isNativePlatform()) return [];

  const found: Track[] = [];
  try {
    onProgress("طلب صلاحية الوصول إلى ملفات الوسائط...");
    await NativeScanner.requestPermissions();

    onProgress("جاري فحص جميع ملفات الهاتف...");
    const res = await NativeScanner.scan();
    const medias: NativeMedia[] = res?.media || [];

    for (const m of medias) {
      found.push({
        id: "scan-" + String(m.id || Math.random()),
        name: stripExt(String(m.name || "بدون اسم")),
        fileName: String(m.name || ""),
        type: m.type === "video" ? "video" : "audio",
        size: Number(m.size) || 0,
        lastModified: Number(m.dateModified) || 0,
        addedAt: Date.now() - found.length,
        blob: null,
        uri: String(m.uri || ""),
        album: m.album ? String(m.album) : undefined,
        artist: m.artist ? String(m.artist) : undefined,
        duration: (Number(m.duration) || 0) / 1000, // مللي → ثوانٍ
      });
    }
    return found;
  } catch (e) {
    console.error("فشل فحص الجهاز:", e);
    return [];
  }
}
