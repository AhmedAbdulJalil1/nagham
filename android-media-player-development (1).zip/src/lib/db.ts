import type { Playlist, Track } from "../types";

const DB_NAME = "nagham-db";
const DB_VERSION = 1;

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb() {
  if (!dbPromise) {
    dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains("tracks"))
          db.createObjectStore("tracks", { keyPath: "id" });
        if (!db.objectStoreNames.contains("meta"))
          db.createObjectStore("meta");
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
}

function reqQ<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

/* ===== الملفات ===== */
export async function dbPutTracks(list: Track[]) {
  const db = await openDb();
  const tx = db.transaction("tracks", "readwrite");
  const st = tx.objectStore("tracks");
  list.forEach((t) => st.put(t));
  await txDone(tx);
}

export async function dbPutTrack(t: Track) {
  const db = await openDb();
  const tx = db.transaction("tracks", "readwrite");
  tx.objectStore("tracks").put(t);
  await txDone(tx);
}

export async function dbGetTracks(): Promise<Track[]> {
  const db = await openDb();
  return reqQ(db.transaction("tracks").objectStore("tracks").getAll());
}

export async function dbDeleteTrack(id: string) {
  const db = await openDb();
  const tx = db.transaction("tracks", "readwrite");
  tx.objectStore("tracks").delete(id);
  await txDone(tx);
}

/* ===== البيانات الوصفية ===== */
export async function dbMetaGet<T>(key: string, fallback: T): Promise<T> {
  const db = await openDb();
  const v = await reqQ(db.transaction("meta").objectStore("meta").get(key));
  return v === undefined ? fallback : (v as T);
}

export async function dbMetaSet(key: string, val: unknown) {
  const db = await openDb();
  const tx = db.transaction("meta", "readwrite");
  tx.objectStore("meta").put(val, key);
  await txDone(tx);
}

export type { Playlist };
