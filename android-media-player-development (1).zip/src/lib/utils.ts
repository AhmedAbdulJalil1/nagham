export const uid = () =>
  Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

export function stripExt(name: string) {
  const i = name.lastIndexOf(".");
  return i > 0 ? name.slice(0, i) : name;
}

export function formatTime(sec: number) {
  if (!isFinite(sec) || sec < 0) sec = 0;
  const s = Math.floor(sec % 60);
  const m = Math.floor(sec / 60) % 60;
  const h = Math.floor(sec / 3600);
  const p = (n: number) => n.toString().padStart(2, "0");
  return h > 0 ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
}

export function formatBytes(b: number) {
  if (!b) return "0 بايت";
  const u = ["بايت", "كيلوبايت", "ميجابايت", "جيجابايت"];
  const i = Math.min(u.length - 1, Math.floor(Math.log(b) / Math.log(1024)));
  return (b / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0) + " " + u[i];
}

export function hashStr(s: string) {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

const GRADS = [
  "linear-gradient(135deg,#7c3aed,#db2777)",
  "linear-gradient(135deg,#0ea5e9,#8b5cf6)",
  "linear-gradient(135deg,#f59e0b,#ef4444)",
  "linear-gradient(135deg,#10b981,#0ea5e9)",
  "linear-gradient(135deg,#ec4899,#f97316)",
  "linear-gradient(135deg,#6366f1,#06b6d4)",
  "linear-gradient(135deg,#a855f7,#ec4899)",
  "linear-gradient(135deg,#22d3ee,#a3e635)",
];

export function artGradient(name: string) {
  return GRADS[hashStr(name) % GRADS.length];
}

export const isMediaFile = (f: File) =>
  f.type.startsWith("audio/") ||
  f.type.startsWith("video/") ||
  /\.(mp3|m4a|aac|ogg|oga|wav|flac|opus|webm|mp4|m4v|mov|mkv|3gp|aac)$/i.test(f.name);

export const isVideoFile = (f: File) =>
  f.type.startsWith("video/") || /\.(mp4|m4v|webm|mov|mkv|3gp)$/i.test(f.name);

/* ===== توليد الصور المصغرة للفيديو + قياس مدة الصوت (تسلسليًا لتجنب الضغط) ===== */
let probeChain: Promise<void> = Promise.resolve();

function enqueue<T>(fn: () => Promise<T>): Promise<T> {
  const p = probeChain.then(fn, fn);
  probeChain = p.then(
    () => undefined,
    () => undefined
  );
  return p;
}

export function generateVideoThumb(blob: Blob): Promise<string> {
  return enqueue(
    () =>
      new Promise<string>((resolve) => {
        const url = URL.createObjectURL(blob);
        const v = document.createElement("video");
        v.muted = true;
        v.playsInline = true;
        v.preload = "metadata";
        v.src = url;
        let done = false;
        const finish = (val: string) => {
          if (done) return;
          done = true;
          window.clearTimeout(t);
          URL.revokeObjectURL(url);
          v.removeAttribute("src");
          resolve(val);
        };
        const t = window.setTimeout(() => finish(""), 9000);
        v.onerror = () => finish("");
        v.onloadeddata = () => {
          v.currentTime = Math.min(1, (v.duration || 2) / 3);
          v.onseeked = () => {
            try {
              const c = document.createElement("canvas");
              c.width = 480;
              c.height = 270;
              const ctx = c.getContext("2d");
              if (!ctx) return finish("");
              ctx.drawImage(v, 0, 0, 480, 270);
              finish(c.toDataURL("image/jpeg", 0.72));
            } catch {
              finish("");
            }
          };
        };
      })
  );
}

export function probeAudioDuration(blob: Blob): Promise<number> {
  return enqueue(
    () =>
      new Promise<number>((resolve) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("audio");
        a.preload = "metadata";
        a.src = url;
        let done = false;
        const finish = (d: number) => {
          if (done) return;
          done = true;
          window.clearTimeout(t);
          URL.revokeObjectURL(url);
          a.removeAttribute("src");
          resolve(d);
        };
        const t = window.setTimeout(() => finish(0), 12000);
        a.onerror = () => finish(0);
        a.onloadedmetadata = () => finish(isFinite(a.duration) ? a.duration : 0);
      })
  );
}
